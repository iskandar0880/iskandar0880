from aiogram import Bot
from aiogram.types import DefaultBotProperties

bot = Bot(token=config.tg_bot.token, default=DefaultBotProperties(parse_mode="HTML"))
