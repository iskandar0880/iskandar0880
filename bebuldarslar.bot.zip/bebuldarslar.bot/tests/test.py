from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart
from keyboards.keyboards import asosiyMenu

olish: Router = Router()

@olish.message()
async def yes(message: Message):
    video_id = message.video.file_id
    await message.reply(video_id)  