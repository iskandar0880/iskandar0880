from aiogram.types import ReplyKeyboardMarkup, KeyboardButton 


html = ReplyKeyboardMarkup(
    keyboard=[
        [
        KeyboardButton(text="1-2 dars"),
        KeyboardButton(text="3-4 dars"),
    ],
    [
        KeyboardButton(text="5-6 dars"),
        KeyboardButton(text="7-8 dars")
    ],
    [
        KeyboardButton(text="9-11 dars")
    ],
    [
        KeyboardButton(text="🔙 Orqaga"),
        KeyboardButton(text="🔝 Asosiy Menyu")
    ]
    ],
    resize_keyboard=True
)