from aiogram.types import ReplyKeyboardMarkup, KeyboardButton 


css = ReplyKeyboardMarkup(
    keyboard=[
        [
        KeyboardButton(text="1-2 dars"),
        KeyboardButton(text="3-4 dars"),
    ],
    [
        KeyboardButton(text="5-6 dars"),
        KeyboardButton(text="7-8 dars")
    ],
    [
        KeyboardButton(text="9-10 dars"),
        KeyboardButton(text="11-12 dars")
    ],
    [
        KeyboardButton(text="13-15 dars"),
        KeyboardButton(text="16-18 dars")
    ],
    [
        KeyboardButton(text="19-21 dars"),
        KeyboardButton(text="22-25 dars")
    ],
    [
        KeyboardButton(text="Orqaga 🔙"),
        KeyboardButton(text="🔝 Asosiy Menyu")
    ]
    ],
    resize_keyboard=True
)