from aiogram.types import ReplyKeyboardMarkup, KeyboardButton 


asosiyMenu = ReplyKeyboardMarkup(
    keyboard=[
        [
        KeyboardButton(text="Front-end"),
        KeyboardButton(text="Back-end"),
    ]
   
    ],
    resize_keyboard=True
)

HC = ReplyKeyboardMarkup(
    keyboard=[
        [
        KeyboardButton(text="HTML darslar"),
        KeyboardButton(text="Css darslar"),
    ],
    [
        KeyboardButton(text="🔝 Asosiy Menyu")
    ]
    ],
    resize_keyboard=True
)