from aiogram import Router, F
from aiogram.types import Message
from keyboards.keyboards import HC, asosiyMenu
from keyboards.css import css


SCss: Router = Router()

@SCss.message(F.text=="Css darslar")
async def movie(message:Message):
    await message.answer("Css darslar", reply_markup=css)


@SCss.message(F.text =="1-2 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAONZiul9Iq5r3N8ZcS2P61b6xEPsPEAAvkTAAIF4zlI-Y5SQH7yNaE0BA", caption="CSS darslari | 1-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOOZiul9CldXz5cUo-2GtH9HkUgcFYAAvoTAAIF4zlI6Uy7RqzC2Mc0BA", caption="CSS darslari | 2-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="3-4 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAORZiumVG_1eJHNEtRqzMjBD24XkhAAAvsTAAIF4zlIJOE28XKQVuI0BA", caption="CSS darslari | 3-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOSZiumVNZtXmZ6TXSCFo0zggAB0uItAAL8EwACBeM5SLsOuAk18LulNAQ", caption="CSS darslari | 4-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="5-6 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOWZiumnbX_nv3GmmnU1U-_LmzylQ8AAv0TAAIF4zlIijGw4QABU_qhNAQ", caption="CSS darslari | 5-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOVZiumnXQRgkZ9ERFkbPRZ1A31utcAAv4TAAIF4zlIjqYoJcmLQCA0BA", caption="CSS darslari | 6-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="7-8 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOZZiumyZM4Ub9qdsvRvvXnsY55_y8AAxQAAgXjOUiLf5_LsV85_zQE", caption="CSS darslari | 7-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOaZiumydTl3sdvTZnjaRrY3egemXoAAgEUAAIF4zlIRV5OC7X4tU40BA", caption="CSS darslari | 8-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="9-10 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOdZiunMhdK3k_psUuJWUluVd-PhqQAAgIUAAIF4zlIVOXIWlD-jac0BA", caption="CSS darslari | 9-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOeZiunMjcVlpyCR9XO64Z8wOCcbOkAAgMUAAIF4zlI8cTX-8gL8Qk0BA", caption="CSS darslari | 10-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="11-12 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOhZiund8qsHhRKddTc0mL0jGc18h4AAgQUAAIF4zlIAnFqKkTdOPM0BA", caption="CSS darslari | 11-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOiZiund7fLDR6tgw3uXAYFjJuBh0gAAgUUAAIF4zlI1C1lclNEj400BA", caption="CSS darslari | 12-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="13-15 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOlZiun8Vf2orafYe28ZsEZItSYiA0AAgYUAAIF4zlITFuKO01LPCA0BA", caption="CSS darslari | 13-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOmZiun8fItEpesNV-uQzC9AAEURLeqAAIHFAACBeM5SDDB0PthwTjcNAQ", caption="CSS darslari | 14-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )
    await message.answer_video("BAACAgIAAxkBAAOnZiun8b2B0YI3U90ukgLLMyEF-2UAAgkUAAIF4zlIbgV39QM2ZEY0BA", caption="CSS darslari | 15-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="16-18 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOrZiuoXC15k8xfm9WadJyP0OA4VVYAAgsUAAIF4zlILWDlFC1YMlw0BA", caption="CSS darslari | 16-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOsZiuoXAaSf2LpIJ15V5e3cD4gRDAAAgwUAAIF4zlIrGqkSSdUFy80BA", caption="CSS darslari | 17-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )
    await message.answer_video("BAACAgIAAxkBAAOtZiuoXKtglMk2-jX25n2tEcfT2DsAAg0UAAIF4zlI5DQ96F_TW0I0BA", caption="CSS darslari | 18-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="19-21 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAOxZiuoy08v0uPV6DgGB61h-54794cAAg8UAAIF4zlIqf4ulgAB3zJCNAQ", caption="CSS darslari | 19-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAOyZiuoy1nis7VmoJPY19eJgVABxx4AAhAUAAIF4zlI0VAf8XCi-ak0BA", caption="CSS darslari | 20-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )
    await message.answer_video("BAACAgIAAxkBAAOyZiuoy1nis7VmoJPY19eJgVABxx4AAhAUAAIF4zlI0VAf8XCi-ak0BA", caption="CSS darslari | 21-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text =="22-25 dars")
async def movie(message:Message):
    await message.answer_video("BAACAgIAAxkBAAO3ZiupUsqHArq-6dexMAlG7Jx38AoAAhIUAAIF4zlIQdE64nCZAoI0BA", caption="CSS darslari | 22-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("BAACAgIAAxkBAAO4ZiupUmVnu03C6P2xP5h3AAHwkCndAAITFAACBeM5SMdkU23DsqZ3NAQ", caption="CSS darslari | 23-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )
    await message.answer_video("BAACAgIAAxkBAAO5ZiupUgO__SZzoB2wkT3byAsMsu8AAhQUAAIF4zlIzwlLockMzyQ0BA", caption="CSS darslari | 24-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )
    await message.answer_video("BAACAgIAAxkBAAO6ZiupUs0dWOzLkQN06L_n3Yx1YtgAAhUUAAIF4zlIuvSfslBK1xk0BA", caption="CSS darslari | 25-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )

@SCss.message(F.text=="🔝 Asosiy Menyu")
async def lesson(message:Message):
    await message.answer("🔝 Asosiy Menyu ", reply_markup=asosiyMenu)

@SCss.message(F.text=="Orqaga 🔙")
async def lesson(message:Message):
    await message.answer("Orqaga 🔙", reply_markup=HC)