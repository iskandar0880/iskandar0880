from aiogram import Router, F
from aiogram.types import Message
from keyboards.keyboards import HC, asosiyMenu
from keyboards.html import html


frontend: Router = Router()

@frontend.message(F.text =="Front-end")
async def darslar(message:Message):
    await message.answer("Front-end", reply_markup=HC)


@frontend.message(F.text=="HTML darslar")
async def lesson(message:Message):
    await message.answer("HTML darslar", reply_markup=html)

@frontend.message(F.text =="1-2 dars")
async def video(message:Message):
    await message.answer_video("https://t.me/IT_video_darsliklar/1091", caption="HTML darslari | 1-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("https://t.me/IT_video_darsliklar/1091", caption="HTML darslari | 2-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!" )


@frontend.message(F.text =="3-4 dars")
async def video(message:Message):
    await message.answer_video("https://t.me/if37dax2jj/398", caption="HTML darslari | 3-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("https://t.me/if37dax2jj/398", caption="HTML darslari | 4-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")

@frontend.message(F.text =="5-6 dars")
async def video(message:Message):
    await message.answer_video("https://t.me/if37dax2jj/398", caption="HTML darslari | 5-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("https://t.me/if37dax2jj/398", caption="HTML darslari | 6-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")

@frontend.message(F.text =="7-8 dars")
async def video(message:Message):
    await message.answer_video("https://t.me/if37dax2jj/398", caption="HTML darslari | 7-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("https://t.me/if37dax2jj/398", caption="HTML darslari | 8-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")

@frontend.message(F.text =="9-11 dars")
async def video(message:Message):
    await message.answer_video("https://t.me/if37dax2jj/354", caption="HTML darslari | 9-dars | Asosiy tushunchalar \n \nYoutube — www.youtube.com/c/Alitechacademy  \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("https://t.me/if37dax2jj/354", caption="HTML darslari | 10-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")
    await message.answer_video("https://t.me/if37dax2jj/354", caption="HTML darslari | 11-dars | Asosiy tushunchalar\n \nYoutube — www.youtube.com/c/Alitechacademy \nTelegram — @alitechuz \n\n@FoydaliDarslarbot — IT darslar platformasi!")

@frontend.message(F.text=="🔝 Asosiy Menyu")
async def lesson(message:Message):
    await message.answer("🔝 Asosiy Menyu ", reply_markup=asosiyMenu)

@frontend.message(F.text=="🔙 Orqaga")
async def lesson(message:Message):
    await message.answer("🔙 Orqaga ", reply_markup=HC)