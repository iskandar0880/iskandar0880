from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart
from keyboards.keyboards import asosiyMenu
start_router: Router = Router()

@start_router.message(CommandStart())
async def start(message:Message):
    await message.answer("🔝 Asosiy menyuda siz ! \n \n 🖥 Kompyuter savodxonligi va IT sohasiga doir o'zbekcha, foydali va bepul darslarni ulashuvchi bot.", reply_markup=asosiyMenu)
