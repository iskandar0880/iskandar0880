LEXICON_EN: dict[str, str] = {
    # Commands
    "/start": ...,
    "/help": ...
}
