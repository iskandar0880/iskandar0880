from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

# Router yaratish
socials_router = Router()

# **Ijtimoiy tarmoqlar uchun inline menyu**
socials_inline_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📢 Telegram kanal", url="https://t.me/AIDgroupPortfolio")],
        [InlineKeyboardButton(text="📷 Instagram sahifa", url="https://instagram.com/AIDgroup")]
    ]
)

# **"Bizning ijtimoiy tarmoqlar" tugmasi bosilganda**
@socials_router.message(lambda message: message.text == "🌍 Bizning ijtimoiy tarmoqlar")
async def send_social_links(message: Message):
    text = (
        "🌍 <b>novip — Bizning ijtimoiy tarmoqlar</b>\n\n"
        "📲 <b>novip</b> jamoasi sifatli IT xizmatlarini taqdim etadi va "
        "mijozlarimizga eng yaxshi yechimlarni taklif qilishga harakat qiladi. "
        "Agar siz bizning loyihalarimiz va faoliyatimizni yaqindan kuzatmoqchi bo‘lsangiz, "
        "ijtimoiy tarmoqlarimizga obuna bo‘lishni unutmang! 🎯\n\n"
        
        "🔹 <b>Telegram:</b> Eng so‘nggi yangiliklar, aksiyalar va maxsus takliflar shu yerda! "
        "Shuningdek, portfoliomiz bilan tanishib, mijozlarimizga taqdim etayotgan xizmatlarimiz haqida bilib olishingiz mumkin.\n\n"
        
        "🔹 <b>Instagram:</b> Eng chiroyli dizaynlar, qiziqarli loyihalar va mijozlarimiz uchun eksklyuziv kontent. "
        "Biz qanday ishlashimiz va qanday natijalarga erishayotganimizni ko‘rishingiz mumkin!\n\n"
        
        "📩 Agar sizga professional veb-sayt, Telegram bot yoki boshqa IT xizmatlari kerak bo‘lsa, biz bilan bog‘laning! "
        "Sizning biznesingizni yangi bosqichga olib chiqish uchun biz har doim tayyormiz. 🚀"
    )

    await message.answer(text, parse_mode="HTML", reply_markup=socials_inline_menu)
