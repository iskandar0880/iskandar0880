from aiogram import Router
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import Message

contact_router = Router()
portfolio_router = Router()

# Portfolio uchun Telegram kanal manzili
PORTFOLIO_LINK = "https://t.me/AIDgroupPortfolio"  # Kanal linkini shu yerga qo‘ying

# "📂 Portfolioga o'tish" tugmasi uchun inline keyboard
portfolio_inline_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📂 Portfolioni ko‘rish", url=PORTFOLIO_LINK)]
    ]
)

# "📂 Portfolioga o'tish" tugmasi bosilganda
@portfolio_router.message(lambda message: message.text == "📂 Portfolioga o'tish")
async def send_portfolio_link(message: Message):
    text = (
        "📂 <b>novip portfoliosi</b>\n\n"
        "Bizning jamoamiz tomonidan amalga oshirilgan loyihalar bilan tanishing! 🎯\n\n"
        "✅ <b>Veb-saytlar:</b> Biz yaratgan zamonaviy, tezkor va qulay dizayndagi saytlarni ko‘ring.\n"
        "✅ <b>Telegram botlar:</b> Mijozlarga xizmat ko‘rsatish, avtomatlashtirilgan savdo va xizmatlarni optimallashtirish uchun yaratilgan botlar.\n"
        "✅ <b>Bizning maxsus loyihalar:</b> O‘ziga xos va noyob dasturiy mahsulotlar, CRM tizimlar va SaaS platformalar.\n\n"
        "💡 Agar sizga ham shunday sifatli yechim kerak bo‘lsa, biz bilan bog‘laning! 🎨\n\n"
        "📩 Taklif va buyurtmalar uchun \"📞 Biz bilan bog‘lanish\" tugmasini bosing!"
    )

    await message.answer(text, parse_mode="HTML", reply_markup=portfolio_inline_menu)


# Adminlarning Telegram username'lari
ADMIN_1 = "iskandarbek_off"  # Birinchi admin username
ADMIN_2 = "@asilbekmurodov_08"  # Ikkinchi admin username

# "📞 Biz bilan bog‘lanish" tugmasi uchun inline keyboard
contact_inline_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📞 Admin 1 bilan bog‘lanish", url=f"tg://resolve?domain={ADMIN_1}")],
        [InlineKeyboardButton(text="📞 Admin 2 bilan bog‘lanish", url=f"tg://resolve?domain={ADMIN_2}")]
    ]
)

# "📞 Biz bilan bog‘lanish" tugmasi bosilganda
@contact_router.message(lambda message: message.text == "📞 Biz bilan bog‘lanish")
async def contact_admin(message: Message):
    text = (
        "📞 <b>novip jamoasi bilan bog‘lanish</b>\n\n"
        "Sizning savollaringiz, buyurtmalar va hamkorlik takliflaringizni kutamiz! 🎯\n\n"
        "💼 <b>Xizmatlarimiz:</b>\n"
        "🔹 Veb-sayt yaratish\n"
        "🔹 Telegram bot ishlab chiqish\n"
        "🔹 Dasturiy ta’minot va avtomatlashtirish\n"
        "🔹 IT konsultatsiya va texnik yordam\n\n"
        "📩 Biz bilan bog‘lanish uchun quyidagi tugmalardan birini bosing 👇"
    )
    
    await message.answer(text, parse_mode="HTML", reply_markup=contact_inline_menu)