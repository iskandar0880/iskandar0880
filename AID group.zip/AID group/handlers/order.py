from aiogram import Router
from aiogram.types import Message
from keyboards.keyboards import website_menu, bot_menu, main_menu

order_router = Router()

# Veb-sayt buyurtma bosilganda
@order_router.message(lambda message: message.text == "🌐 Veb-saytga buyurtma berish")
async def order_website(message: Message):
    await message.answer("🌐 Qanday turdagi veb-sayt kerak?", reply_markup=website_menu)

# Bot buyurtma bosilganda
@order_router.message(lambda message: message.text == "🤖 Botga buyurtma berish")
async def order_bot(message: Message):
    await message.answer("🤖 Qanday turdagi bot kerak?", reply_markup=bot_menu)

# Ortga tugmasi bosilganda
@order_router.message(lambda message: message.text == "🔙 Ortga")
async def back_to_main(message: Message):
    await message.answer("🔝 Asosiy menyuga qaytdingiz.", reply_markup=main_menu)
