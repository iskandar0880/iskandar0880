from aiogram import Router
from aiogram.types import Message
from keyboards.keyboards import prices_menu, main_menu  # Tugmalarni import qilamiz
import html  

prices_router: Router = Router()

@prices_router.message(lambda message: message.text == "📊 Narxlar")
async def show_prices_menu(message: Message):
    await message.answer("📊 Qaysi xizmat narxlarini bilmoqchisiz?", reply_markup=prices_menu)

@prices_router.message(lambda message: message.text == "💻 Veb-sayt narxlari")
async def show_website_prices(message: Message):
    text = (
        "<b>🌐 Veb-sayt narxlari (O‘zbekiston bo‘yicha):</b>\n\n"
        "🔹 Vizitka sayt –<i>399 ming - 1,5 mln so‘m</i>\n"
        "🔹 Korporativ sayt – <i>1,5 mln - 3 mln so‘m</i>\n"
        "🔹 Internet-do‘kon – <i>2.5 mln - 5 mln so‘m</i>\n"
        "🔹 Maxsus loyiha (CRM, SaaS, ERP) – <i>8 mln so‘mdan boshlab</i>\n\n"
        "⚡️ Narxlar loyihaga bog‘liq holda o‘zgarishi mumkin."
    )
    await message.answer(text, parse_mode="HTML")

@prices_router.message(lambda message: message.text == "🤖 Bot narxlari")
async def show_bot_prices(message: Message):
    text = (
            "<b>🤖 Telegram bot narxlari (O‘zbekiston bo‘yicha):</b>\n\n"
        "🔹 Oddiy bot – <i>499 ming - 999 ming so‘m</i>\n"
        "🔹 Savdo bot  – <i>999 ming so‘m - 2,5 mln so‘m</i>\n"
        "🔹 Xizmat bot  – <i>2,5 mln - 5 mln + so‘m</i>\n"
        "🔹 AI yoki maxsus bot  – <i>6 mln + so‘mdan boshlab</i>\n\n"
        "⚡️ To‘liq loyiha uchun biz bilan bog‘laning!"
    )
    await message.answer(text, parse_mode="HTML")

@prices_router.message(lambda message: message.text == "⬅️ Ortga")
async def go_back(message: Message):
    await message.answer("🔙 Asosiy menyuga qaytdingiz.", reply_markup=main_menu)
