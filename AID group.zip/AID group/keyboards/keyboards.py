from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

# Asosiy menyu tugmalari
main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🌐 Veb-saytga buyurtma berish")],
        [KeyboardButton(text="🤖 Botga buyurtma berish")],
        [KeyboardButton(text="📊 Narxlar"), KeyboardButton(text="📞 Biz bilan bog‘lanish")],
        [KeyboardButton(text="📂 Portfolioga o'tish")],
        [KeyboardButton(text="🌍 Bizning ijtimoiy tarmoqlar")]
    ],
    resize_keyboard=True
)

# Narxlar menyusi
prices_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💻 Veb-sayt narxlari"), KeyboardButton(text="🤖 Bot narxlari")],
        [KeyboardButton(text="⬅️ Ortga")]
    ],
    resize_keyboard=True
)

# Veb-sayt buyurtma menyusi
website_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📝 Vizitka sayt"), KeyboardButton(text="🏢 Korporativ sayt")],
        [KeyboardButton(text="🛒 Internet-do‘kon"), KeyboardButton(text="🔧 Maxsus loyiha")],
        [KeyboardButton(text="🔙 Ortga")]
    ],
    resize_keyboard=True
)

# Bot buyurtma menyusi
bot_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💬 Oddiy bot"), KeyboardButton(text="🛍 Savdo bot")],
        [KeyboardButton(text="⚙ Xizmat bot"), KeyboardButton(text="🤖 AI yoki maxsus bot")],
        [KeyboardButton(text="🔙 Ortga")]
    ],
    resize_keyboard=True
)
