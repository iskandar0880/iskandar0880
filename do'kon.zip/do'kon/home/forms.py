from django import forms
from .models import Product


class ProductForm(forms.ModelForm):

    class Meta:
        model = Product
        fields = "__all__"
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Mahsulot nomi'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Mahsulot haqida ma\'lumot', 'rows': 5}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Narxi'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Miqdori'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control'}),  # ImageField uchun widget
            # Boshqa maydonlar uchun widgetlar ham qo'shishingiz mumkin
        }