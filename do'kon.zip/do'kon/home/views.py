from django.shortcuts import render, redirect
from .models import Product, Income
from .forms import ProductForm
def home(request):
    dbProduct = Product.objects.all()
    context = {
        "Products": dbProduct
    }
    return render(request, 'index.html', context)

def korish_product(request, pk):
    maxsulot = Product.objects.get(pk=pk)
    if request.method == "POST":
        soni = request.POST.get("soni")
        maxsulot.quantity -= int(soni)
        maxsulot.save()
        
        income = Income()

        income.name = maxsulot.name
        income.price = maxsulot.price
        income.quantity = soni
        income.save()

        if maxsulot.quantity == 0:
            maxsulot.delete()
        return redirect('home')
    context = {
        "Product": maxsulot
    }
    return render(request, 'korish_product.html', context)

def qoshish_product(request):
    forms = ProductForm()
    if request.method == "POST":
        forms = ProductForm(request.POST, request.FILES)
        if forms.is_valid():
            forms.save()
            return redirect("home")
    else:
        return render(request, 'qoshish_product.html', {"forms":forms})
    

def income(request):
    income = Income.objects.all()
    summalar =[]
    for summa in income:
        summalar.append(summa.price * summa.quantity)
        jamisumma = sum(summalar)
    context = {
        "income": income,
        "jamisumma": jamisumma
    }
    return render(request, "income.html", context)