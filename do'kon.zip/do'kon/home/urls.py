from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
urlpatterns = [
    path("", views.home, name="home"),
    path("korish_product/<int:pk>", views.korish_product, name="korish_product"),
    path("qoshish_product/", views.qoshish_product, name="qoshish_product"),
    path("income/", views.income, name="income"),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
