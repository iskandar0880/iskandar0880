from django.db import models


# Product model - Mahsulot ma'lumotlari
class Product(models.Model):

    # Mahsulot nomi (char - belgilar)
    name = models.CharField(max_length=255, verbose_name="Mahsulot nomi")

    # Mahsulot narxi (float - suzuvchi nuqta soni)
    price = models.FloatField(verbose_name="Mahsulot narxi")

    # Mahsulot qo'shilgan sana (date - sana turi)
    date = models.DateTimeField(verbose_name="Qo'shilgan sana", auto_now_add=True)

    # Mahsulot haqida batafsil ma'lumot (text - matnli ma'lumot)
    description = models.TextField(verbose_name="Mahsulot tavsifi")

    # Mahsulot miqdori (int - butun son)
    quantity = models.IntegerField(verbose_name="Mahsulot miqdori")

    # Mahsulot rasmi (ImageField - tasvir saqlash)
    image = models.ImageField(upload_to='products/', verbose_name="Mahsulot rasmi")

    class Meta:
        db_table = "product"

    def __str__(self):
        return self.name

# User model - Foydalanuvchi ma'lumotlari
class User(models.Model):

    # Foydalanuvchi ismi (char - belgilar)
    name = models.CharField(max_length=255, verbose_name="Foydalanuvchi ismi")

    # Parol (char - belgilar)
    password = models.CharField(max_length=255, verbose_name="Parol")

    # Reyting (int - butun son)
    rate = models.IntegerField(default=0, verbose_name="Reyting")

    # Yosh (int - butun son)
    age = models.IntegerField(verbose_name="Yosh")

    # Email manzil (char - belgilar)
    email = models.EmailField(max_length=255, unique=True, verbose_name="Email")

    # Telefon raqam (char - belgilar)
    phoneNumber = models.CharField(max_length=20, verbose_name="Telefon raqam")

    # Foydalanuvchi rasmi (ImageField - tasvir saqlash)
    image = models.ImageField(upload_to='users/', null=True, blank=True, verbose_name="Foydalanuvchi rasmi")

    # Rol (char - foydalanuvchining roli, masalan admin yoki oddiy foydalanuvchi)
    role = models.CharField(max_length=50, choices=[('admin', 'Admin'), ('user', 'Foydalanuvchi')], verbose_name="Rol")

    class Meta:
        db_table = "user"

    def __str__(self):
        return self.name

# Income model - Daromad ma'lumotlari
class Income(models.Model):

    # Daromad nomi (char - belgilar)
    name = models.CharField(max_length=255, verbose_name="Daromad nomi")

    # Miqdor (bigint - katta butun son)
    quantity = models.BigIntegerField(verbose_name="Miqdor")

    # Narx (bigint - katta butun son)
    price = models.BigIntegerField(verbose_name="Narx")

    # Qo'shilgan sana (datetime - vaqt va sana turi)
    date = models.DateTimeField(auto_now_add=True, verbose_name="Qo'shilgan vaqt")

    class Meta:
        db_table = "income"

    def __str__(self):
        return self.name

# Cost model - Xarajatlar ma'lumotlari
class Cost(models.Model):

    # Xarajat nomi (char - belgilar)
    name = models.CharField(max_length=255, verbose_name="Xarajat nomi")

    # Narx (bigint - katta butun son)
    price = models.BigIntegerField(verbose_name="Narx")

    # Xarajat haqida batafsil ma'lumot (text - matnli ma'lumot)
    description = models.TextField(verbose_name="Tavsif")

    # Mahsulot qo'shilgan sana (date - sana turi)
    date = models.DateTimeField(verbose_name="Qo'shilgan sana", auto_now_add=True)

    
    class Meta:
        db_table = "cost"

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    quantity = models.PositiveIntegerField()
    date = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='product_images/', blank=True, null=True)  # Rasm uchun maydon
    
