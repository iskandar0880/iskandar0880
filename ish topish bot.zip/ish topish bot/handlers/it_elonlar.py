from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from keyboards.channels_keyboard import channels_inline_keyboard
from keyboards.contact_keyboard import contact_keyboard
from keyboards.online_offline import online_offline_keyboard
from keyboards.minu import main_menu
from handlers.forms import ITForm
import html
import logging

it_router = Router()

CHANNELS = {
    "IT sohalar bo‘yicha e’lonlar": -1002692851977,
}

@it_router.message(F.text == "Ishchi berish bo‘yicha e'lon berish")
async def show_channels_inline(message: Message, state: FSMContext):
    await state.clear()  # Eski ma’lumotlarni tozalab ketamiz
    await message.answer("Salom, e'lon turini tanlang:", reply_markup=channels_inline_keyboard)


@it_router.callback_query(F.data == "it_elon")
async def it_start(callback: CallbackQuery, state: FSMContext):
    await state.update_data(channel="IT sohalar bo‘yicha e’lonlar")
    await callback.message.answer("1. Korxona nomi:")
    await state.set_state(ITForm.korxona)
    await callback.answer()

@it_router.message(ITForm.korxona)
async def it_korxona(message: Message, state: FSMContext):
    await state.update_data(korxona=message.text)
    await message.answer("2. Ish beruvchi ismi:")
    await state.set_state(ITForm.ismi)

@it_router.message(ITForm.ismi)
async def it_ismi(message: Message, state: FSMContext):
    await state.update_data(ismi=message.text)
    await message.answer("3. Iltimos, telefon raqamingizni yuboring:", reply_markup=contact_keyboard)
    await state.set_state(ITForm.tel)

@it_router.message(ITForm.tel)
async def it_tel(message: Message, state: FSMContext):
    if message.contact:
        await state.update_data(tel=message.contact.phone_number)
        await message.answer("4. Hududni kiriting:")
        await state.set_state(ITForm.hudud)
    else:
        await message.answer("❗Iltimos, tugma orqali telefon raqamingizni yuboring.")

@it_router.message(ITForm.hudud)
async def it_hudud(message: Message, state: FSMContext):
    await state.update_data(hudud=message.text)
    await message.answer("5. Ish sharoiti (izoh):")
    await state.set_state(ITForm.sharoit)
# ffff
@it_router.message(ITForm.sharoit)
async def it_sharoit(message: Message, state: FSMContext):
    await state.update_data(sharoit=message.text)
    await message.answer("6. Ish ko‘rinishini tanlang:", reply_markup=online_offline_keyboard)
    await state.set_state(ITForm.turi)

@it_router.callback_query(F.data.in_({"online", "offline"}))
async def it_choose_turi(callback: CallbackQuery, state: FSMContext):
    turi = "Online" if callback.data == "online" else "Ofline"
    await state.update_data(turi=turi)
    await callback.message.edit_text(f"✅ Siz tanladingiz: {turi}")
    await callback.message.answer("7. Ish bo‘yicha izoh:")
    await state.set_state(ITForm.izoh)
    await callback.answer()

@it_router.message(ITForm.izoh)
async def it_finish(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()

    # Avval channel bor-yo‘qligini tekshiramiz
    channel_name = data.get("channel")
    if not channel_name:
        await message.answer("❌ Avval e'lon turini tanlang. Iltimos, /start tugmasini bosing va e'lon turini tanlang.")
        await state.clear()
        return

    kanal_id = CHANNELS.get(channel_name)
    if kanal_id is None:
        await message.answer("❌ Kanal ID topilmadi. Iltimos, kanal nomini tekshiring.")
        await state.clear()
        return

    korxona = html.escape(data['korxona'])
    ismi = html.escape(data['ismi'])
    tel = html.escape(data['tel'])
    hudud = html.escape(data['hudud'])
    sharoit = html.escape(data['sharoit'])
    turi = html.escape(data['turi'])
    izoh = html.escape(message.text)

    username = message.from_user.username
    if username:
        username_text = f"🔗 Telegram: <a href='https://t.me/{username}'>@{username}</a>"
    else:
        username_text = f"🔗 Telegram: <a href='tg://user?id={message.from_user.id}'>Foydalanuvchi</a>"

    matn = (
        f"<b>{channel_name}</b>\n\n"
        f"🏢 Korxona: {korxona}\n"
        f"👤 Ish beruvchi: {ismi}\n"
        f"📞 Tel: {tel}\n"
        f"📍 Hudud: {hudud}\n"
        f"🏗 Sharoit: {sharoit}\n"
        f"🌐 Ko‘rinish: {turi}\n"
        f"📝 Izoh: {izoh}\n"
        f"{username_text}"
    )

    try:
        await bot.send_message(kanal_id, matn, parse_mode="HTML", disable_web_page_preview=True)
        await message.answer("✅ E'lon yuborildi.")
    except Exception as e:
        logging.error(f"Xabar yuborishda xatolik: {e}")
        await message.answer(f"❌ Xabar yuborishda xatolik: {e}")

    await state.clear()
    await message.answer("🏠 Asosiy menyuga qaytdingiz.", reply_markup=main_menu)
