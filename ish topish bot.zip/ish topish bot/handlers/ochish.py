# # handlers/ochish.py
# from aiogram import Router, F
# from aiogram.types import Message, ReplyKeyboardRemove

# och_router = Router()

# @och_router.message(F.text == "Ish topish bo‘yicha e'lon berish")
# async def ish_topish(msg: Message):
#     await msg.answer(
#         "👷‍♂️ Ish topish bo‘yicha e'lon berish tanlandi.",
#         reply_markup=ReplyKeyboardRemove()
#     )

# @och_router.message(F.text == "Ishchi berish bo‘yicha e'lon berish")
# async def ishchi_berish(msg: Message):
#     await msg.answer(
#         "🏭 Ishchi berish bo‘yicha e'lon berish tanlandi.",
#         reply_markup=ReplyKeyboardRemove()
#     )

# @och_router.message(F.text == "💳 To‘lov qilish")
# async def tolov_qilish(msg: Message):
#     await msg.answer(
#         "💳 To‘lov bo‘limi tanlandi.",
#         reply_markup=ReplyKeyboardRemove()
#     )

# @och_router.message(F.text == "👤 Shaxsiy kabinet")
# async def shaxsiy_kabinet(msg: Message):
#     await msg.answer(
#         "👤 Shaxsiy kabinet bo‘limi tanlandi.",
#         reply_markup=ReplyKeyboardRemove()
#     )

# @och_router.message(F.text == "❓ Yordam")
# async def yordam(msg: Message):
#     await msg.answer(
#         "❓ Yordam bo‘limi tanlandi. Sizga qanday yordam kerak?",
#         reply_markup=ReplyKeyboardRemove()
#     )
