from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from loader import bot
from handlers.forms import IshlabChiqarishForm
from keyboards.contact_keyboard import contact_keyboard
from keyboards.minu import main_menu

ishlap_router = Router()

CHANNEL_ID = -1002580353859  # kanal ID

# 🔔 Inline tugma bosilganda FSM boshlanishi
@ishlap_router.callback_query(F.data == "ishlab_chiqarish")
async def start_ishlab_chiqarish_callback(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("1. Korxona nomini yuboring:")
    await state.set_state(IshlabChiqarishForm.korxona)
    await callback.answer()

# 1. Korxona
@ishlap_router.message(IshlabChiqarishForm.korxona)
async def korxona_qabul(msg: Message, state: FSMContext):
    await state.update_data(korxona=msg.text)
    await msg.answer("2. Ish beruvchi ismini yuboring:")
    await state.set_state(IshlabChiqarishForm.ismi)

# 2. Ish beruvchi
@ishlap_router.message(IshlabChiqarishForm.ismi)
async def ismi_qabul(msg: Message, state: FSMContext):
    await state.update_data(ismi=msg.text)
    await msg.answer("3. Qanday ishlab chiqarish turi? (masalan: metall, kiyim, plastik):")
    await state.set_state(IshlabChiqarishForm.ishlab_turi)

# 3. Ishlab chiqarish turi
@ishlap_router.message(IshlabChiqarishForm.ishlab_turi)
async def ishlab_turi_qabul(msg: Message, state: FSMContext):
    await state.update_data(ishlab_turi=msg.text)
    await msg.answer("4. Qanday ishchi kerak? (misol: yuk tashuvchi, vaqtincha ishchi):")
    await state.set_state(IshlabChiqarishForm.ishchi_izoh)

# 4. Ishchi izoh
@ishlap_router.message(IshlabChiqarishForm.ishchi_izoh)
async def ishchi_izoh_qabul(msg: Message, state: FSMContext):
    await state.update_data(ishchi_izoh=msg.text)
    await msg.answer("5. Qo‘shimcha izohingizni yozing (yoki 'yo‘q' deb yozing):")
    await state.set_state(IshlabChiqarishForm.izoh)

# 5. Yakuniy izoh va e’lonni yuborish
@ishlap_router.message(IshlabChiqarishForm.izoh)
async def yakuniy(msg: Message, state: FSMContext):
    await state.update_data(izoh=msg.text)
    data = await state.get_data()

    username = msg.from_user.username
    if username:
        username_text = f"👤 <b>Telegram username:</b> @{username}"
    else:
        username_text = "👤 <b>Telegram username:</b> Yo‘q"

    matn = (
        f"🏭 <b>Korxona:</b> {data['korxona']}\n"
        f"👨‍💼 <b>Ish beruvchi:</b> {data['ismi']}\n"
        f"🏗 <b>Ishlab chiqarish turi:</b> {data['ishlab_turi']}\n"
        f"🧑‍🔧 <b>Ishchi kerak:</b> {data['ishchi_izoh']}\n"
        f"📝 <b>Izoh:</b> {data['izoh']}\n"
        f"{username_text}"
    )

    await bot.send_message(chat_id=CHANNEL_ID, text=matn, parse_mode="HTML")
    await msg.answer("✅ E’lon kanalga yuborildi.", reply_markup=main_menu)
    await state.clear()
