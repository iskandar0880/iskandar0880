from aiogram import Router, Bot
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.filters import CommandStart
from keyboards.minu import main_menu
import html

start_router = Router()

required_channels = [
    {"name": "IT", "url": "https://t.me/ish_bor_IT", "id": -1002692851977},
    {"name": "Vaqtinchalik ish", "url": "https://t.me/Ish_bor_vaqtichaish", "id": -1002377492354},
    {"name": "Biznes", "url": "https://t.me/Ish_bor_biznesiz", "id": -1002642076434},
    {"name": "Ishlab chiqarish", "url": "https://t.me/ish_bor_ishlapchiqauv", "id": -1002580353859},
]

@start_router.message(CommandStart())
async def start_handler(message: Message, bot: Bot):
    user_id = message.from_user.id
    user_full_name = html.escape(message.from_user.full_name)
    not_joined = []

    for channel in required_channels:
        try:
            member = await bot.get_chat_member(chat_id=channel["id"], user_id=user_id)
            if member.status not in ["member", "administrator", "creator"]:
                not_joined.append(channel)
        except Exception as e:
            print(f"Xatolik: {e}")
            not_joined.append(channel)

    if not_joined:
        buttons = [
            [InlineKeyboardButton(text=f"🔗 {channel['name']}", url=channel["url"])]
            for channel in not_joined
        ]
        buttons.append([InlineKeyboardButton(text="✅ Obuna bo‘ldim", callback_data="check_subs")])
        markup = InlineKeyboardMarkup(inline_keyboard=buttons)

        await message.answer(
            "📢 Botdan foydalanish uchun quyidagi kanallarga obuna bo‘ling 👇",
            reply_markup=markup
        )
        return

    welcome_text = (
        f"👋 Assalomu alaykum, <b>{user_full_name}</b>!\n\n"
        "🛠 <b>“ISH BOR”</b> botiga xush kelibsiz! Bu yerda siz quyidagi imkoniyatlardan foydalanishingiz mumkin:\n\n"
        "🔍 <b>Ish izlash</b> — kasbingizga mos vaqtincha yoki doimiy ish toping.\n"
        "📢 <b>Ishchi e’loni berish</b> — sizga kerakli mutaxassislarni tez toping.\n"
        "💳 <b>To‘lov</b> — e’lonlaringizni ko‘proq odam ko‘rishi uchun ularni targ‘ib qiling.\n"
        "👤 <b>Shaxsiy kabinet</b> — barcha e’lonlaringizni boshqaring.\n\n"
        "📢 E’lonlaringiz quyidagi kanallarga ham joylashtiriladi:\n"
        "🔗 <a href='https://t.me/ish_bor_IT'>IT sohasidagi ishlar</a>\n"
        "🔗 <a href='https://t.me/Ish_bor_vaqtichaish'>Vaqtincha ishlar</a>\n"
        "🔗 <a href='https://t.me/Ish_bor_biznesiz'>Biznes va shaxsiy yordam</a>\n"
        "🔗 <a href='https://t.me/ish_bor_ishlapchiqauv'>Ishlab chiqarishdagi ishlar</a>\n\n"
        "❓ Savollaringiz bo‘lsa, <b>“Yordam”</b> bo‘limi orqali murojaat qiling."
    )

    await message.answer(
        text=welcome_text,
        reply_markup=main_menu,
        parse_mode="HTML"
    )

@start_router.callback_query(lambda c: c.data == "check_subs")
async def check_subs(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    not_joined = []

    for channel in required_channels:
        try:
            member = await bot.get_chat_member(chat_id=channel["id"], user_id=user_id)
            if member.status not in ["member", "administrator", "creator"]:
                not_joined.append(channel)
        except Exception as e:
            print(f"Xatolik: {e}")
            not_joined.append(channel)

    if not_joined:
        await callback.answer("❗ Hali hamma kanallarga obuna bo‘lmagansiz!", show_alert=True)
    else:
        await callback.message.delete()
        await callback.message.answer(
            reply_markup=main_menu
        )
