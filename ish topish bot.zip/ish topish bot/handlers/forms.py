from aiogram.fsm.state import State, StatesGroup

# 💻 IT sohasi uchun forma
class ITForm(StatesGroup):
    korxona = State()
    ismi = State()
    tel = State()
    hudud = State()
    sharoit = State()
    turi = State()
    izoh = State()

# ⏳ Vaqtincha ish joylari uchun forma
class VaqtinchaForm(StatesGroup):
    korxona = State()
    ismi = State()
    tel = State()
    ishchi_turi = State()
    izoh = State()

# 🏭 Ishlab chiqarish e’loni uchun forma
class IshlabChiqarishForm(StatesGroup):
    korxona = State()
    ismi = State()
    ishlab_turi = State()
    ishchi_izoh = State()
    izoh = State()

# 📦 Biznesingiz bo‘yicha e’lon forma
class BiznesForm(StatesGroup):
    turi = State()
    ismi = State()
    tel = State()
