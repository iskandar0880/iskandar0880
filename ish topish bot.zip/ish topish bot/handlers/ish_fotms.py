# 📁 forms/ish_topish_form.py
from aiogram.fsm.state import State, StatesGroup

class ITIshTopishForm(StatesGroup):
    hodim_ismi = State()
    yosh = State()
    texnologiya = State()
    telegram = State()
    hudud = State()
    maosh = State()
    kasbi = State()
    vaqt = State()
    maqsad = State()
    
    
class VaqtinchaIshFSM(StatesGroup):
    ism = State()
    tel = State()
    ish_turi = State()
    maosh = State()
    izoh = State()

# 📁 forms/ishlabchiqarish_form.py
from aiogram.fsm.state import State, StatesGroup

class IshlabChiqarishForm(StatesGroup):
    hodim_ismi = State()
    tel_raqami = State()
    hunar = State()
    hudud = State()
    yosh = State()
    jinsi = State()
    maqsad = State()

# 📁 forms/biznes_form.py
from aiogram.fsm.state import State, StatesGroup

class BiznesForm(StatesGroup):
    ismi = State()
    yosh = State()
    jinsi = State()
    tel = State()
    maqsad = State()

# 📁 forms/vaqtincha_form.py
from aiogram.fsm.state import State, StatesGroup

class VaqtinchaForm(StatesGroup):
    ismi = State()
    hunar = State()
    jinsi = State()
    tel = State()

# Telegram avtomatik olish uchun yordamchi funksiya

def get_telegram_link(user):
    username = user.username
    return f"@{username}" if username else "yo'q"

# 📁 shartlar/elon_shartlari.py
def get_elon_shartlari():
    return """
📝 E'lon berish shartlari:

1. Faqat real ish va ishchi e'lonlari.
2. Noo'rin so'zlar, reklamalar, yoki yolg'on ma'lumotlar taqiqlanadi.
3. Kontakt ma'lumotlari aniq bo'lishi kerak.
4. Adminlar e'lonlarni tasdiqlash yoki rad etish huquqiga ega.
"""
