from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram import Router, F
from keyboards.ish_joy import ish_joy_keyboard

ishTop_router = Router()

@ishTop_router.message(F.text == "Ish topish bo‘yicha e'lon berish")
async def ish_topish(msg: Message):
    await msg.answer(
        "Quyidagi bo‘limlardan birini tanlang 👇",
        reply_markup=ish_joy_keyboard
    )




    

@ishTop_router.callback_query(F.data == "ish_ishlab")
async def handle_ishlab(call: CallbackQuery):
    await call.message.edit_text("🏭 Ishlab chiqarish bo‘yicha e’lonlar bo‘limi. Bu yerda siz ...")

@ishTop_router.callback_query(F.data == "ish_biznes")
async def handle_biznes(call: CallbackQuery):
    await call.message.edit_text("📈 Biznesga oid ishlar bo‘limi. Bu yerda siz ...")
