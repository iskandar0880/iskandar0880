from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from handlers.ish_fotms import BiznesForm
from keyboards.jins_keyboard import jins_inline

biz_router = Router()
CHANNEL_ID = -1002642076434  # Siz bergan kanal ID

@biz_router.callback_query(F.data == "ish_biznes")
async def biznes_start(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("Ismingizni yozing:")
    await state.set_state(BiznesForm.ismi)

@biz_router.message(BiznesForm.ismi)
async def get_ismi(message: types.Message, state: FSMContext):
    await state.update_data(ismi=message.text)
    await message.answer("Yoshingizni yozing:")
    await state.set_state(BiznesForm.yosh)

@biz_router.message(BiznesForm.yosh)
async def get_yosh(message: types.Message, state: FSMContext):
    await state.update_data(yosh=message.text)
    await message.answer("Jinsingizni tanlang:", reply_markup=jins_inline)
    await state.set_state(BiznesForm.jinsi)

@biz_router.callback_query(F.data.startswith("jins_"), BiznesForm.jinsi)
async def get_jins(callback: types.CallbackQuery, state: FSMContext):
    jins = callback.data.replace("jins_", "").capitalize()
    await state.update_data(jinsi=jins)
    await callback.message.edit_text(f"✅ Jins tanlandi: {jins}")
    
    await callback.message.answer("Telefon raqamingizni yozing:")
    await state.set_state(BiznesForm.tel)

@biz_router.message(BiznesForm.tel)
async def get_tel(message: types.Message, state: FSMContext):
    await state.update_data(tel=message.text)
    await message.answer("Maqsadingizni yozing:")
    await state.set_state(BiznesForm.maqsad)

@biz_router.message(BiznesForm.maqsad)
async def get_maqsad(message: types.Message, state: FSMContext):
    await state.update_data(maqsad=message.text)
    data = await state.get_data()
    
    text = (
        f"📢 <b>Biznes sohasida ish qidiruvchidan e'lon:</b>\n\n"
        f"👤 Ismi: {data['ismi']}\n"
        f"🎂 Yosh: {data['yosh']}\n"
        f"⚧ Jinsi: {data['jinsi']}\n"
        f"📞 Tel: {data['tel']}\n"
        f"🎯 Maqsad: {data['maqsad']}"
    )

    # Foydalanuvchiga javob
    await message.answer("✅ E'loningiz qabul qilindi va kanalga yuborildi.", parse_mode="HTML")
    
    # Kanalga yuborish
    await message.bot.send_message(chat_id=CHANNEL_ID, text=text, parse_mode="HTML")

    # Holatni tozalash
    await state.clear()
