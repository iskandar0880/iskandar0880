from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from handlers.forms import BiznesForm
from keyboards.contact_keyboard import contact_keyboard
from keyboards.minu import main_menu
from loader import bot

biznes_router = Router()
CHANNEL_ID = -1002642076434  # <-- o'zingizning kanal ID'ingizni kiriting

# 📦 Inline tugmadan bosilganda biznes e’loni boshlanadi
@biznes_router.callback_query(F.data == "biznes_elon")
async def start_biznes_inline(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("1. Biznes turini yozing (masalan: kafeteriy, do‘kon, xizmat va h.k.):")
    await state.set_state(BiznesForm.turi)

# 1. Biznes turi
@biznes_router.message(BiznesForm.turi)
async def qabul_turi(msg: Message, state: FSMContext):
    await state.update_data(turi=msg.text)
    await msg.answer("2. Ismingizni yozing:")
    await state.set_state(BiznesForm.ismi)

# 2. Ism
@biznes_router.message(BiznesForm.ismi)
async def qabul_ismi(msg: Message, state: FSMContext):
    await state.update_data(ismi=msg.text)
    await msg.answer("3. Telefon raqamingizni yuboring:", reply_markup=contact_keyboard)
    await state.set_state(BiznesForm.tel)

# 3. Telefon raqamni contact ko‘rinishida qabul qilish
@biznes_router.message(BiznesForm.tel, F.contact)
async def qabul_tel_contact(msg: Message, state: FSMContext):
    await state.update_data(tel=msg.contact.phone_number)

    username = msg.from_user.username
    await state.update_data(tg_username=username)

    data = await state.get_data()

    if username:
        username_text = f"👤 <b>Telegram username:</b> @{username}"
    else:
        username_text = "👤 <b>Telegram username:</b> Yo‘q"

    matn = (
        f"📦 <b>Biznes e’loni</b>\n"
        f"🏪 <b>Biznes turi:</b> {data['turi']}\n"
        f"👤 <b>Ism:</b> {data['ismi']}\n"
        f"📞 <b>Telefon:</b> {data['tel']}\n"
        f"{username_text}"
    )

    await bot.send_message(chat_id=CHANNEL_ID, text=matn, parse_mode="HTML")
    await msg.answer("✅ E’lon muvaffaqiyatli kanalga yuborildi!", reply_markup=main_menu)
    await state.clear()

# Telefon raqam matn ko‘rinishida yuborilsa
@biznes_router.message(BiznesForm.tel)
async def qabul_tel_text(msg: Message, state: FSMContext):
    await state.update_data(tel=msg.text)

    username = msg.from_user.username
    await state.update_data(tg_username=username)

    data = await state.get_data()

    if username:
        username_text = f"👤 <b>Telegram username:</b> @{username}"
    else:
        username_text = "👤 <b>Telegram username:</b> Yo‘q"

    matn = (
        f"📦 <b>Biznes e’loni</b>\n"
        f"🏪 <b>Biznes turi:</b> {data['turi']}\n"
        f"👤 <b>Ism:</b> {data['ismi']}\n"
        f"📞 <b>Telefon:</b> {data['tel']}\n"
        f"{username_text}"
    )

    await bot.send_message(chat_id=CHANNEL_ID, text=matn, parse_mode="HTML")
    await msg.answer("✅ E’lon muvaffaqiyatli kanalga yuborildi!", reply_markup=main_menu)
    await state.clear()
