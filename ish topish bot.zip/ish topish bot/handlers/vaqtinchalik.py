from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from handlers.ish_fotms import VaqtinchaIshFSM, get_telegram_link
from keyboards.minu import main_menu
from keyboards.contact_keyboard import contact_keyboard

vq_router = Router()
VAQTINCHA_CHANNEL_ID = -1002377492354  # Kanal yoki guruh ID

@vq_router.callback_query(F.data == "ish_vaqt")
async def vaqtincha_ish_start(call: CallbackQuery, state: FSMContext):
    await call.message.answer("1. Ismingizni kiriting:")
    await state.set_state(VaqtinchaIshFSM.ism)

@vq_router.message(VaqtinchaIshFSM.ism)
async def qabul_ism(message: Message, state: FSMContext):
    await state.update_data(ism=message.text)
    await message.answer("2. Iltimos, telefon raqamingizni yuboring:", reply_markup=contact_keyboard)
    await state.set_state(VaqtinchaIshFSM.tel)

@vq_router.message(VaqtinchaIshFSM.tel)
async def qabul_tel(message: Message, state: FSMContext):
    if message.contact:
        phone = message.contact.phone_number
    else:
        phone = message.text

    await state.update_data(tel=phone)
    await message.answer("3. Qanday ish turini xohlaysiz?")
    await state.set_state(VaqtinchaIshFSM.ish_turi)

@vq_router.message(VaqtinchaIshFSM.ish_turi)
async def qabul_ish_turi(message: Message, state: FSMContext):
    await state.update_data(ish_turi=message.text)
    await message.answer("4. Oylik maosh kutayotgan miqdoringizni kiriting:")
    await state.set_state(VaqtinchaIshFSM.maosh)

@vq_router.message(VaqtinchaIshFSM.maosh)
async def qabul_maosh(message: Message, state: FSMContext):
    await state.update_data(maosh=message.text)
    await message.answer("5. Qo‘shimcha izohlaringiz bo‘lsa yozing (yoki 'yo‘q' deb yozing):")
    await state.set_state(VaqtinchaIshFSM.izoh)

@vq_router.message(VaqtinchaIshFSM.izoh)
async def yakuniy_ish(message: Message, state: FSMContext, bot: Bot):
    await state.update_data(izoh=message.text)
    data = await state.get_data()
    telegram_link = get_telegram_link(message.from_user)

    text = (
        "<b>🛠 Vaqtincha ish izlovchi</b>\n\n"
        f"👤 Ism: {data.get('ism')}\n"
        f"📞 Telefon: {data.get('tel')}\n"
        f"🔧 Ish turi: {data.get('ish_turi')}\n"
        f"💰 Maosh: {data.get('maosh')}\n"
        f"📌 Izoh: {data.get('izoh')}\n"
        f"{telegram_link}"
    )

    try:
        await bot.send_message(chat_id=VAQTINCHA_CHANNEL_ID, text=text, parse_mode="HTML")
        await message.answer("✅ Ma'lumotlaringiz vaqtinchalik ish kanaliga yuborildi.")
    except Exception as e:
        await message.answer(f"❌ Xatolik yuz berdi: {e}")

    await state.clear()
    await message.answer("🏠 Asosiy menyuga qaytdingiz.", reply_markup=main_menu)
