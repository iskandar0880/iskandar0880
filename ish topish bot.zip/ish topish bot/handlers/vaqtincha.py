from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from handlers.forms import VaqtinchaForm
from keyboards.contact_keyboard import contact_keyboard
from keyboards.minu import main_menu
from loader import bot

vaqt_router = Router()

CHANNEL_ID = -1002377492354  # Kanal ID ni shu yerga yozing

# ⏳ Inline tugmadan bosilganda FSM boshlanadi
@vaqt_router.callback_query(F.data == "vaqtinchalik_ish")
async def start_vaqtincha_inline(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("1. Korxona nomini yozing:")
    await state.set_state(VaqtinchaForm.korxona)
    await callback.answer()  # callbackni acknowledge qilish tavsiya etiladi

# 1. Korxona
@vaqt_router.message(VaqtinchaForm.korxona)
async def qabul_korxona(msg: Message, state: FSMContext):
    await state.update_data(korxona=msg.text)
    await msg.answer("2. Ish beruvchi ismini yozing:")
    await state.set_state(VaqtinchaForm.ismi)

# 2. Ish beruvchi
@vaqt_router.message(VaqtinchaForm.ismi)
async def qabul_ismi(msg: Message, state: FSMContext):
    await state.update_data(ismi=msg.text)
    await msg.answer("3. Telefon raqamingizni yuboring:", reply_markup=contact_keyboard)
    await state.set_state(VaqtinchaForm.tel)

# 3. Telefon (kontakt orqali)
@vaqt_router.message(VaqtinchaForm.tel, F.contact)
async def qabul_tel(msg: Message, state: FSMContext):
    await state.update_data(tel=msg.contact.phone_number)
    await msg.answer("4. Qanday ishchi kerak? (misol: yuk tashuvchi, vaqtincha ishchi):", reply_markup=None)
    await state.set_state(VaqtinchaForm.ishchi_turi)

# Agar telefon raqam matn ko‘rinishida keladigan bo‘lsa (fallback)
@vaqt_router.message(VaqtinchaForm.tel)
async def qabul_tel_text(msg: Message, state: FSMContext):
    await state.update_data(tel=msg.text)
    await msg.answer("4. Qanday ishchi kerak? (misol: yuk tashuvchi, vaqtincha ishchi):", reply_markup=None)
    await state.set_state(VaqtinchaForm.ishchi_turi)

# 4. Ishchi turi va yakuniy e’lonni kanalga yuborish
@vaqt_router.message(VaqtinchaForm.ishchi_turi)
async def qabul_izoh(msg: Message, state: FSMContext):
    await state.update_data(ishchi_turi=msg.text)
    data = await state.get_data()

    username = msg.from_user.username
    if username:
        username_text = f"👤 <b>Telegram username:</b> @{username}"
    else:
        username_text = "👤 <b>Telegram username:</b> Yo‘q"

    matn = (
        f"⏳ <b>Vaqtincha ish joyi</b>\n"
        f"🏢 <b>Korxona:</b> {data.get('korxona', 'Malumot yo‘q')}\n"
        f"👤 <b>Ish beruvchi:</b> {data.get('ismi', 'Malumot yo‘q')}\n"
        f"📞 <b>Aloqa:</b> {data.get('tel', 'Malumot yo‘q')}\n"
        f"🧑‍🔧 <b>Ishchi kerak:</b> {data.get('ishchi_turi', 'Malumot yo‘q')}\n"
        f"{username_text}"
    )

    await bot.send_message(chat_id=CHANNEL_ID, text=matn, parse_mode="HTML")
    await msg.answer("✅ E’lon muvaffaqiyatli kanalga yuborildi!", reply_markup=main_menu)
    await state.clear()
