from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from handlers.ish_fotms import ITIshTopishForm, get_telegram_link
from keyboards.contact_keyboard import contact_keyboard
from keyboards.tugma import tugma
from keyboards.minu import main_menu
from keyboards.ish_joy import ish_joy_keyboard


ish_router = Router()
IT_CHANNEL_ID = -1002692851977  # IT ish kanalingiz ID si

@ish_router.callback_query(F.data == "ish_it")
async def ish_it_callback(call: CallbackQuery, state: FSMContext):
    await call.message.answer("👤 Ismingizni kiriting:")
    await state.set_state(ITIshTopishForm.hodim_ismi)


@ish_router.message(ITIshTopishForm.hodim_ismi)
async def ism_qabul(message: Message, state: FSMContext):
    await state.update_data(hodim_ismi=message.text)
    await message.answer("2. Yoshingizni kiriting:")
    await state.set_state(ITIshTopishForm.yosh)

@ish_router.message(ITIshTopishForm.yosh)
async def yosh_qabul(message: Message, state: FSMContext):
    await state.update_data(yosh=message.text)
    await message.answer("3. Biladigan texnologiyalaringiz (masalan: Python, Django, JS):")
    await state.set_state(ITIshTopishForm.texnologiya)

@ish_router.message(ITIshTopishForm.texnologiya)
async def texnologiya_qabul(message: Message, state: FSMContext):
    await state.update_data(texnologiya=message.text)
    await message.answer("4. Yashash hududingizni kiriting:")
    await state.set_state(ITIshTopishForm.hudud)

@ish_router.message(ITIshTopishForm.hudud)
async def hudud_qabul(message: Message, state: FSMContext):
    await state.update_data(hudud=message.text)
    await message.answer("5. Oylik maoshdan kutayotgan miqdoringiz (so‘m):")
    await state.set_state(ITIshTopishForm.maosh)

@ish_router.message(ITIshTopishForm.maosh)
async def maosh_qabul(message: Message, state: FSMContext):
    await state.update_data(maosh=message.text)
    await message.answer("6. Sizning kasbingiz (masalan: Backend developer):")
    await state.set_state(ITIshTopishForm.kasbi)

@ish_router.message(ITIshTopishForm.kasbi)
async def kasbi_qabul(message: Message, state: FSMContext):
    await state.update_data(kasbi=message.text)
    await message.answer("7. Qanday ish turini xohlaysiz?", reply_markup=tugma)
    await state.set_state(ITIshTopishForm.vaqt)

@ish_router.callback_query(ITIshTopishForm.vaqt)
async def vaqt_qabul(call: CallbackQuery, state: FSMContext):
    vaqt = "Online" if call.data == "onlines" else "Oflines"
    await state.update_data(vaqt=vaqt)

    print(f"Foydalanuvchi tanlagan vaqt: {vaqt}")  

    await call.message.edit_text(f"✅ Siz tanladingiz: {vaqt}")
    await call.message.answer("8. Maqsadingiz (nechchi oy/dan keyin ish boshlamoqchisiz va h.k.):")
    await state.set_state(ITIshTopishForm.maqsad)
# fgg
@ish_router.message(ITIshTopishForm.maqsad)
async def maqsad_handler(message: Message, state: FSMContext, bot: Bot):
    await state.update_data(maqsad=message.text)
    data = await state.get_data()
    telegram_link = get_telegram_link(message.from_user)

    matn = (
        "<b>🧑‍💻 IT sohasida ish izlovchi</b>\n\n"
        f"👤 Ism: {data.get('hodim_ismi', 'Nomaʼlum')}\n"
        f"🕑 Yosh: {data.get('yosh', 'Nomaʼlum')}\n"
        f"💻 Texnologiya: {data.get('texnologiya', 'Nomaʼlum')}\n"
        f"📍 Hudud: {data.get('hudud', 'Nomaʼlum')}\n"
        f"💰 Maosh: {data.get('maosh', 'Nomaʼlum')}\n"
        f"👨‍💼 Kasbi: {data.get('kasbi', 'Nomaʼlum')}\n"
        f"🌐 Ish turi: {data.get('vaqt', 'Nomaʼlum')}\n"
        f"🎯 Maqsad: {data.get('maqsad', 'Nomaʼlum')}\n"
        f"{telegram_link}"
    )

    try:
        await bot.send_message(IT_CHANNEL_ID, matn, parse_mode="HTML", disable_web_page_preview=True)
        await message.answer("✅ Ma'lumotlaringiz IT ishlar kanaliga yuborildi.")
    except Exception as e:
        await message.answer(f"❌ Xatolik yuz berdi: {e}")

    await state.clear()
    await message.answer("🏠 Asosiy menyuga qaytdingiz.", reply_markup=main_menu)