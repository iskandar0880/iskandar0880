from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from handlers.ish_fotms import IshlabChiqarishForm
from keyboards.contact_keyboard import contact_keyboard
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from handlers.ish_fotms import get_telegram_link
from keyboards.minu import main_menu

ishlab_router = Router()
ISHLAB_CHANNEL_ID = -1002580353859  # Kanal ID

# Jins tanlash uchun inline tugma
jins_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="👨 Erkak", callback_data="jins_erkak"),
        InlineKeyboardButton(text="👩 Ayol", callback_data="jins_ayol")
    ]
])

@ishlab_router.callback_query(F.data == "ish_ishlab")
async def start_ishlab(call: CallbackQuery, state: FSMContext):
    await call.message.answer("1. Ismingizni kiriting:")
    await state.set_state(IshlabChiqarishForm.hodim_ismi)

@ishlab_router.message(IshlabChiqarishForm.hodim_ismi)
async def ism_qabul(message: Message, state: FSMContext):
    await state.update_data(hodim_ismi=message.text)
    await message.answer("2. Telefon raqamingizni yuboring:", reply_markup=contact_keyboard)
    await state.set_state(IshlabChiqarishForm.tel_raqami)

@ishlab_router.message(IshlabChiqarishForm.tel_raqami)
async def tel_qabul(message: Message, state: FSMContext):
    phone = message.contact.phone_number if message.contact else message.text
    await state.update_data(tel_raqami=phone)
    await message.answer("3. Qaysi hunarga egasiz?")
    await state.set_state(IshlabChiqarishForm.hunar)

@ishlab_router.message(IshlabChiqarishForm.hunar)
async def hunar_qabul(message: Message, state: FSMContext):
    await state.update_data(hunar=message.text)
    await message.answer("4. Qaysi hududdansiz?")
    await state.set_state(IshlabChiqarishForm.hudud)

@ishlab_router.message(IshlabChiqarishForm.hudud)
async def hudud_qabul(message: Message, state: FSMContext):
    await state.update_data(hudud=message.text)
    await message.answer("5. Yoshingiz nechida?")
    await state.set_state(IshlabChiqarishForm.yosh)

@ishlab_router.message(IshlabChiqarishForm.yosh)
async def yosh_qabul(message: Message, state: FSMContext):
    await state.update_data(yosh=message.text)
    await message.answer("6. Jinsingizni tanlang:", reply_markup=jins_keyboard)
    await state.set_state(IshlabChiqarishForm.jinsi)

@ishlab_router.callback_query(F.data.startswith("jins_"))
async def jinsi_qabul(call: CallbackQuery, state: FSMContext, bot: Bot):
    jins = "Erkak" if call.data == "jins_erkak" else "Ayol"
    await state.update_data(jinsi=jins)
    await call.message.answer("7. Ishdan maqsadingiz nima?")
    await state.set_state(IshlabChiqarishForm.maqsad)

@ishlab_router.message(IshlabChiqarishForm.maqsad)
async def yakunlash(message: Message, state: FSMContext, bot: Bot):
    await state.update_data(maqsad=message.text)
    data = await state.get_data()
    telegram_link = get_telegram_link(message.from_user)

    text = (
        "<b>🏭 Ishlab chiqarish sohasida ish izlovchi</b>\n\n"
        f"👤 Ismi: {data.get('hodim_ismi')}\n"
        f"📞 Telefon: {data.get('tel_raqami')}\n"
        f"🔧 Hunari: {data.get('hunar')}\n"
        f"📍 Hudud: {data.get('hudud')}\n"
        f"📅 Yoshi: {data.get('yosh')}\n"
        f"🧍‍♂️ Jinsi: {data.get('jinsi')}\n"
        f"🎯 Maqsadi: {data.get('maqsad')}\n"
        f"{telegram_link}"
    )

    try:
        await bot.send_message(chat_id=ISHLAB_CHANNEL_ID, text=text, parse_mode="HTML")
        await message.answer("✅ Ma'lumotlaringiz yuborildi.")
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")

    await state.clear()
    await message.answer("🏠 Asosiy menyuga qaytdingiz.", reply_markup=main_menu)
