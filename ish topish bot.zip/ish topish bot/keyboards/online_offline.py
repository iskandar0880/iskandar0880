from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

online_offline_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="🌐 Online", callback_data="online")],
        [InlineKeyboardButton(text="🏢 Ofline", callback_data="ofline")],
    ]
)
