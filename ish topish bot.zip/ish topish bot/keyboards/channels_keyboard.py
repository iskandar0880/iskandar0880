from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

channels_inline_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="💻 IT sohalaridagi yangi imkoniyatlar", callback_data="it_elon")],
        [InlineKeyboardButton(text="🛠 Vaqtincha ish joylari takliflari", callback_data="vaqtinchalik_ish")],
        [InlineKeyboardButton(text="🏭 Ishlab chiqarish e’lonlari (ishchilar qidirilmoqda)", callback_data="ishlab_chiqarish")],
        [InlineKeyboardButton(text="📈 Biznesingiz uchun reklama va e’lonlar", callback_data="biznes_elon")]
    ]
)
