# keyboards/main_menu.py
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Ish topish bo‘yicha e'lon berish"),
            KeyboardButton(text="Ishchi berish bo‘yicha e'lon berish"),
        ],
        [
            KeyboardButton(text="💳 To‘lov qilish"),
            KeyboardButton(text="👤 Shaxsiy kabinet"),
        ],
        [
            KeyboardButton(text="❓ Yordam"),
        ],
    ],
    resize_keyboard=True
)
