from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

ish_turlari_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Sotuvchi", callback_data="Sotuvchi")],
    [InlineKeyboardButton(text="Kurier", callback_data="Kurier")],
    [InlineKeyboardButton(text="Ofitsiant", callback_data="Ofitsiant")],
    [InlineKeyboardButton(text="Boshqa", callback_data="Boshqa")],
])
