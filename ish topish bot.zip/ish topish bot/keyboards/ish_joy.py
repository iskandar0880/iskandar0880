from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

ish_joy_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="💻 IT sohasida ish izlayman", callback_data="ish_it"),
    ],
    [
        InlineKeyboardButton(text="⏳ Vaqtincha ish izlayman", callback_data="ish_vaqt"),
    ],
    [
        InlineKeyboardButton(text="🏭 Ishlab chiqarish sohasida ish qidirmoqdaman", callback_data="ish_ishlab"),
    ],
    [
        InlineKeyboardButton(text="🚀 Biznes sohasida ish izlayman", callback_data="ish_biznes"),
    ]
])
