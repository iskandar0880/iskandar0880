from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

jins_inline = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="👨 Erkak", callback_data="jins_erkak"),
        InlineKeyboardButton(text="👩 Ayol", callback_data="jins_ayol")
    ]
])
