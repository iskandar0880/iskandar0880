from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

tugma = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="🌐 Online", callback_data="onlines")],
        [InlineKeyboardButton(text="🏢 Ofline", callback_data="oflines")],
    ]
)
