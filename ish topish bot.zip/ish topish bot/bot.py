import asyncio
import logging
from aiogram import Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage  # <-- FSM uchun
from loader import bot, db
from handlers.start import start_router
from handlers.it_elonlar import it_router
from handlers import echo
from handlers.ishlapchiqarish import ishlap_router
from handlers.vaqtincha import vaqt_router
from handlers.ish_top import ishTop_router
from handlers.biznes import biznes_router
from handlers.it_ish import ish_router
from handlers.vaqtinchalik import vq_router
from handlers.ish_ishlab import ishlab_router
from handlers.biznes_ish import biz_router

# from handlers.ochish import och_router

logger = logging.getLogger(__name__)

async def main():
    logging.basicConfig(level=logging.INFO)
    logger.info("🤖 Bot ishga tushmoqda...")

    try:
        db.create_table_users()
    except Exception as err:
        logger.error(f"📛 DB jadval yaratishda xatolik: {err}")

    # ✅ FSM uchun MemoryStorage qo‘shildi
    dp = Dispatcher(storage=MemoryStorage())

    # 🔗 Routerlarni ulayapmiz
    dp.include_router(start_router)
    dp.include_router(biz_router)  # Biznes ishlar uchun router
    dp.include_router(vq_router)  # Vaqtincha ishlar uchun router
    dp.include_router(it_router)  
    dp.include_router(ishlap_router)
    dp.include_router(ishlab_router)
    dp.include_router(vaqt_router)
    dp.include_router(biznes_router)
    dp.include_router(ishTop_router)
    dp.include_router(ish_router)
    # dp.include_router(och_router)
    dp.include_router(echo.router)

    # 🚀 Botni ishga tushurish
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("🛑 Bot to‘xtatildi")
