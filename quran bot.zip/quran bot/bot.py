import asyncio
import logging
from aiogram import  Dispatcher
from handlers.echo import router
from loader import bot
from keyboards.al_auran_audio import starta_router
from handlers.start import start_router
from keyboards.ilen_tugmalar import ilei_router
logger = logging.getLogger(__name__)


async def main():
    logging.basicConfig(
        level=logging.INFO,
       
    )

    logger.info("Starting bot")


    dp: Dispatcher = Dispatcher()

    dp.include_routers( 
       start_router,
       starta_router,
       ilei_router,
        router

    )



        
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped")
