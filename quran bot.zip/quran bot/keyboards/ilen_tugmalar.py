from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram import Router
from keyboards.al_quran_tugma import but
from aiogram.types import Message,CallbackQuery
from aiogram import types,F
from loader import bot
router = Router()

ilei_router: Router = Router()

inline_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text=" 🔊Qurʼondagi 114 suralarning audiosi",callback_data="bir" ),
        ],
        # [
        #     InlineKeyboardButton(text="🔊Qurʼondagi 114 suralarning tarjimasi", callback_data=" ikki")
        # ],
        # [
        #       InlineKeyboardButton(text="🪄Qurʼondagi 114 suralarning matni", callback_data="good") 
        # ],
          [
              InlineKeyboardButton(text="⁉️Qurʼondagi 114 suralardan savol-javob", callback_data="good1") 
        ]
    ]
)
ot = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot") 
        ]
    ]
)
ot_ = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot_") 
        ]
    ]
)
ot1 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot1") 
        ]
    ]
)
ot2 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot2") 
        ]
    ]
)
ot3 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot3") 
        ]
    ]
)
ot4 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot4") 
        ]
    ]
)
ot5 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot5") 
        ]
    ]
)
ot6 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot6") 
        ]
    ]
)
ot7 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot7") 
        ]
    ]
)
ot8 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot8") 
        ]
    ]
)

ot9 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot9") 
        ]
    ]
)
ot10 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot10") 
        ]
    ]
)
ot11 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot11") 
        ]
    ]
)
ot12 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot12") 
        ]
    ]
)
ot13 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot13") 
        ]
    ]
)
ot14 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot14") 
        ]
    ]
)
ot15 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot16") 
        ]
    ]
)
ot17 = InlineKeyboardMarkup(
 
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot17") 
        ]
    ]
)
ot18 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot18") 
        ]
    ]
)
ot19 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot19") 
        ]
    ]
)

ot16 = InlineKeyboardMarkup(
    inline_keyboard=[

          [
              InlineKeyboardButton(text="✅yangi savolar", callback_data="ot16") 
        ]
    ]
)

@ilei_router.callback_query(F.data == 'bir')
async def process_callback_bir(callback_query: CallbackQuery):
    await bot.send_message(chat_id=callback_query.from_user.id,text="malumot turi talandi",  reply_markup=but)

@ilei_router.callback_query(F.data == 'good1')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning nechta surasi bor?",options=["A) 114","B) 112","C) 120","D) 110"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot)   

@ilei_router.callback_query(F.data == 'ot')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’on qaysi payg’ambar tomonidan Allohning so’zi sifatida insoniyatga yetkazilgan?",options=["A) Muso (a.s)","B) Ibrohim (a.s)","C) Muhammad (s.a.v)","D) Isa (a.s)"],type="quiz",correct_option_id=2,open_period=25, is_anonymous = False,reply_markup=ot_)   
@ilei_router.callback_query(F.data == 'ot_')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning dastlabki nozil bo’lgan oyati qaysi surada joylashgan?",options=["A) Al-Baqara","B) Al-'Alaq","C) Al-Fatiha","D) An-Nisa’"],type="quiz",correct_option_id=2,open_period=25, is_anonymous = False,reply_markup=ot1)   
@ilei_router.callback_query(F.data == 'ot1')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onda nechta juz’ (para) mavjud?",options=["A) 30","B) 60","C) 24","D) 40"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot2)
@ilei_router.callback_query(F.data == 'ot2')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi “Qalbning surasi” deb ataladi?",options=["A) Yasin","B) Ar-Rahman","C) Al-Mulk","D) Al-Kawthar"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot3)
@ilei_router.callback_query(F.data == 'ot3')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning eng uzun surasi qaysi?",options=["A) Al-Baqara","B) Al-'Imran","C) An-Nisa","D) Al-A’raf"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot5) 
@ilei_router.callback_query(F.data == 'ot5')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onda nechta sajdah ayatlari mavjud?",options=["A) 14","B) 15","C) 7","D) 10"],type="quiz",correct_option_id=2,open_period=25, is_anonymous = False,reply_markup=ot6)   
@ilei_router.callback_query(F.data == 'ot6')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’on qaysi tilga nozil qilingan?",options=["A) Arab","B) Farsi","C) Ibroni","D) Turki"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot7)   
@ilei_router.callback_query(F.data == 'ot11')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi barcha namozlarda o’qiladi?",options=["A) Al-Fatiha","B) Al-Ikhlas","C) Al-Falaq","D) An-Nas"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot8)   
@ilei_router.callback_query(F.data == 'ot17')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onda “Bismillahir Rahmanir Rahim” iborasi nechta surada keltirilmagan?",options=["A) 1","B) 9","C)114","D)2"],type="quiz",correct_option_id=3,open_period=25, is_anonymous = False,reply_markup=ot9)   @ilei_router.callback_query(F.data == 'ot9')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi faqatgina Allohning sifatlarini zikr etadi?",options=["A) Al-Ikhlas","B) Al-Kafirun","C) Al-Falaq","D) An-Nas"],type="quiz",correct_option_id=1,open_period=25, is_anonymous = False,reply_markup=ot10)  
@ilei_router.callback_query(F.data == 'ot10')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi nomi hayvon nomi bilan atalgan?",options=["A) Al-Baqara (Sigir)","B) Al-Ankabut (O’rgimchak)","C) Al-Naml (Chumoli)","D) Barchasi to’g’ri"],type="quiz",correct_option_id=3,open_period=25, is_anonymous = False,reply_markup=ot11)   
@ilei_router.callback_query(F.data == 'ot7')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onda zikr etilgan birinchi jang qaysi?",options=["A) Badr jangi","B) Uhud jangi","C) Khandaq jang","D) Tabuk jangi"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot12)   

@ilei_router.callback_query(F.data == 'ot12')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onda nechta harf mavjud?",options=["A) Taxminan 77,000","B) Taxminan 320,000","C) Taxminan 500,000","D) Taxminan 660,000"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot13)   
@ilei_router.callback_query(F.data == 'ot13')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi faqatgina bir sahobaning nomi bilan atalgan?",options=["A) Surah Maryam","B) Surah Luqman","C) Surah Yunus","D) Surah Muhammad"],type="quiz",correct_option_id=3,open_period=25, is_anonymous = False,reply_markup=ot14)   
@ilei_router.callback_query(F.data == 'ot14')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasida barcha oyatlar boshida “Alif, Lam, Meem” deb boshlanadi?",options=["A) Surah Al-Baqara","B) Surah Al-'Imran","C) Surah Al-Ankabut","D) Surah Ar-Rum "],type="quiz",correct_option_id=1,open_period=25, is_anonymous = False,reply_markup=ot3)   
@ilei_router.callback_query(F.data == 'ot15')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi “Sajdah” deb nomlanadi va unda nechta sajdah ayati mavjud?",options=["A) Surah As-Sajdah, 1 ta sajdah ayati","B) Surah Fussilat, 2 ta sajdah ayatlari","C) Surah An-Najm, 3 ta sajdah ayatlari","D) Surah Al-Inshiqaq, 4 ta sajdah ayatlari"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot16)   
























@ilei_router.callback_query(F.data == 'ot16')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi faqatgina jannat va do’zax haqida gapiradi?",options=["A) Surah Al-Waqi’ah","B) Surah Az-Zumar","C) Surah Ar-Rahman","D) Surah Al-Qariah"],type="quiz",correct_option_id=0,open_period=25, is_anonymous = False,reply_markup=ot17)   
@ilei_router.callback_query(F.data == 'ot17')
async def good1(query: CallbackQuery):
    await bot.send_poll(chat_id=query.from_user.id, question="Qur’onning qaysi surasi Allohning i haqida gapiradi?",options=["A) Surah Al-Kursi","B) Surah Al-A’raf","C) Surah Ta-Ha","D) Surah Al-Hadid"],type="quiz",correct_option_id=1,open_period=25, is_anonymous = False,reply_markup=ot19)   @ilei_router.callback_query(F.data == 'ot')
