
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import Message










but = ReplyKeyboardMarkup(
keyboard = [
    [
    KeyboardButton(text="Al-Fatiha (Ochilish)"),
    KeyboardButton(text="Al-Baqarah (Buqa)")
      ],
    [ 
    KeyboardButton(text="Aali 'Imran (Imron oilasi)"),
    KeyboardButton(text="An-Nisa (Ayollar)")
    ],
    # Qolgan suralar uchun tugmalar
    [
    KeyboardButton(text="An-Nisa (Ayollar)"),
    KeyboardButton(text="Al-An'am (Chorva hayvonlari)")
    ],
    [
    KeyboardButton(text="Al-A'raf (Balandliklar)"),
    KeyboardButton(text="Al-Anfal (G'animatlar)")
    ],
    [
    KeyboardButton(text="At-Tawbah (Tavba)"),
    KeyboardButton(text="Yunus (Yunus)")
      ],
    [
    KeyboardButton(text="Hud (Hud)"),
    KeyboardButton(text="Yusuf (Yusuf)")
      ],
    [
    KeyboardButton(text="Ar-Ra'd (Momaqaldiroq)"),
    KeyboardButton(text="Ibrahim (Ibrohim)")
    ],
    [
    KeyboardButton(text="Al-Hijr (Hijr)"), 
    KeyboardButton(text="An-Nahl (Asalarilar)")
    ],
    [
    KeyboardButton(text="Al-Isra (Isro)"),
    KeyboardButton(text="Al-Kahf (G'or)")
    ],
    [
    KeyboardButton(text="Maryam (Maryam)"),
    KeyboardButton(text="Ta-Ha (Ta-Ha)")
    ],
    [
    KeyboardButton(text="Al-Anbiya (Payg'ambarlar)"),
    KeyboardButton(text="Al-Hajj (Haj)")
    ],
    [
    KeyboardButton(text="Al-Mu'minun (Mo'minlar)"),
    KeyboardButton(text="An-Nur (Nur)")
    ],
    [
    KeyboardButton(text="Al-Furqan (Furqon)"), 
    KeyboardButton(text="Ash-Shu'ara (Shoirlar)")
    ],
    [
    KeyboardButton(text="An-Naml (Naml)"),
    KeyboardButton(text="Al-Qasas (Qissalar)")
    ],
    [
    KeyboardButton(text="Al-Ankabut (O'rgimchak)"),
    KeyboardButton(text="Ar-Rum (Rumliklar)")
    ],
    [
    KeyboardButton(text="Luqman (Luqmon)"),
    KeyboardButton(text="As-Sajda (Sajda)")
    ],
    [
    KeyboardButton(text="Al-Ahzab (Ittifoqlar)"), 
    KeyboardButton(text="Saba' (Sabo)")
    ],
    [
    KeyboardButton(text="Fatir (Yaratuvchilar)"),
    KeyboardButton(text="Ya-Sin (Ya Sin)")
    ],
    [
    KeyboardButton(text="As-Saffat (Saf tortganlar)"),
    KeyboardButton(text="Sad (Sad)")
    ],
    [
    KeyboardButton(text="Az-Zumar (Guruhlar)"), 
     KeyboardButton(text="Ghafir (Gunohlarini kechiruvchi)")
    ],
    [
    KeyboardButton(text="Fussilat (Tafsilotlar)"),
    KeyboardButton(text="Ash-Shura (Maslahat)")
    ],
    [
    KeyboardButton(text="Az-Zukhruf (Zeb-ziynat)"),
    KeyboardButton(text="Ad-Dukhan (Tutun)")
    ],
    [
    KeyboardButton(text="Al-Jathiya (Tizzalarni bukuvchilar)"),
    KeyboardButton(text="Al-Ahqaf (Qum tepaliklari)")
    ],
    [
    KeyboardButton(text="Muhammad (Muhammad)"),
    KeyboardButton(text="Al-Fath (Fath)")
    ],
    [
    KeyboardButton(text="Al-Hujurat (Xonalar)"),
    KeyboardButton(text="Qaf (Qof)")
    ],
    [
    KeyboardButton(text="Az-Zariyat"),
    KeyboardButton(text="At-Tur (Tur tog'i)")
    ],
    [
    KeyboardButton(text="An-Najm (Yulduz)"),
    KeyboardButton(text="Al-Qamar (Oy)")
    ],
    [
    KeyboardButton(text="Ar-Rahman (Mehribon)"), 
    KeyboardButton(text="Al-Waqi'a (Voqea)")
    ],
    [
    KeyboardButton(text="Al-Hadid (Temir)"),
    KeyboardButton(text="Al-Mujadila (Munozara qiluvchi ayol)")
    ],
    [
    KeyboardButton(text="Al-Hashr (Ko'chirish)"),
    KeyboardButton(text="Al-Mumtahina (Sinovdan o'tkazilgan ayol)")
    ],
    [
    KeyboardButton(text="As-Saff (Saf)"),
    KeyboardButton(text="Al-Jumu'ah (Juma)")
    ],
    [
    
    KeyboardButton(text="Al-Munafiqun (Munofiqlar)"),
    KeyboardButton(text="At-Taghabun (Zarar ko'rish)")
    ],
    [
    KeyboardButton(text="At-Talaq (Taloq)"),
    KeyboardButton(text="At-Tahrim (Harom qilish)")
    ],
    [
    KeyboardButton(text="Al-Mulk (Mulk)"),
    KeyboardButton(text="Al-Qalam (Qalam)")
    ],
    [
    KeyboardButton(text="Al-Haqqah (Haqiqat)"),
    KeyboardButton(text="Al-Ma'arij (Ma'rij)")
    ],
    [
    KeyboardButton(text="Nuh (Nuh)"),
    KeyboardButton(text="Al-Jinn (Jinlar)")
    ],
    [
    KeyboardButton(text="Al-Muzzammil (O'ralgan kishi)"),
    KeyboardButton(text="Al-Muddathir (O'ranib olgan kishi)")
    ],
    [
    KeyboardButton(text="Al-Qiyama (Qiyomat)"),
    KeyboardButton(text="Al-Insan (Inson)")
    ],
    [
    KeyboardButton(text="Al-Mursalat (Elchilar)"),
    KeyboardButton(text="An-Naba' (Xabar)")
    ],
    [
    KeyboardButton(text="An-Nazi'at (Qo'zg'olonchilar)"), 
    KeyboardButton(text="Abasa (Yuz burdi)")
    ],
    [
    KeyboardButton(text="At-Takwir (Bukilish)"),
    KeyboardButton(text="Al-Infitar (Yorilish)")
    ],
    [
    KeyboardButton(text="Al-Mutaffifin (Kamchilik qiluvchilar)"),
    KeyboardButton(text="Al-Inshiqaq (Yorilish)")
    ],
    [
    KeyboardButton(text="Al-Buruj (Burjlar)"),
    KeyboardButton(text="At-Tariq (Yulduz)")
    ],
    [
    KeyboardButton(text="Al-A'la (Eng oliy)"),
    KeyboardButton(text="Al-Ghashiya (Qoplovchi)")
    ],
    [
    KeyboardButton(text="Al-Fajr (Tong)"),
    KeyboardButton(text="Al-Balad (Shahar)")
    ],
    [
    KeyboardButton(text="Ash-Shams (Quyosh)"), 
    KeyboardButton(text="Al-Lail (Tun)")
    ],
    [
    KeyboardButton(text="Ad-Duha (Tonggi yorug'lik)"),
    KeyboardButton(text="Ash-Sharh (Kengaytirish)")
    ],
    [
    KeyboardButton(text="At-Tin (Anjir)"),
    KeyboardButton(text="Al-Alaq (Xo'ploq)")
    ],
    [
    KeyboardButton(text="Al-Qadr (Qadr kechasi)"),
    KeyboardButton(text="Al-Bayyina (Aniq dalil)")
    ],
    [
    KeyboardButton(text="Az-Zalzala (Zilzila)"),
    KeyboardButton(text="Al-Adiyat (Yuguruvchilar)")
    ],
    [
    KeyboardButton(text="Al-Qari'a (Qo'ng'iroq)"),
    KeyboardButton(text="At-Takathur (Ko'paytirish)")
    ],
    [
    KeyboardButton(text="Al-Asr (Asr)"),
    KeyboardButton(text="Al-Humaza (G'iybatchi)")
    ],
    [
    KeyboardButton(text="Al-Fil (Fil)"),
    KeyboardButton(text="Quraish (Quraysh)")
    ],
    [
    KeyboardButton(text="Al-Ma'un (Yordam)"),
    KeyboardButton(text="Al-Kawthar (Kavsar)")
    ],
    [
    KeyboardButton(text="Al-Kafirun (Kofirlar)"),
    KeyboardButton(text="An-Nasr (Yordam)")
    ],
    [
    KeyboardButton(text="Al-Masad (Palm fiber)"),
    KeyboardButton(text="Al-Ikhlas (Ihlos)")
      ],
    [
    KeyboardButton(text="Al-Falaq (Tong)"),
    KeyboardButton(text="An-Nas (Insonlar)")
    ],
],
  resize_keyboard=True
)


