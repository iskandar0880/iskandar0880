from aiogram import Router
from aiogram.types import Message
from aiogram import F

starta_router: Router = Router()







@starta_router.message(F.text == "Al-Fatiha (Ochilish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/117")   

@starta_router.message(F.text == "Al-Baqarah (Buqa)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/4")

@starta_router.message(F.text == "Aali 'Imran (Imron oilasi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/5")  

@starta_router.message(F.text == "An-Nisa (Ayollar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/6") 

@starta_router.message(F.text == "Al-An'am (Chorva hayvonlari)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/8")

@starta_router.message(F.text == "Al-A'raf (Balandliklar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/9")  
 
@starta_router.message(F.text == "Al-Anfal (G'animatlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/10")  
 
@starta_router.message(F.text == "At-Tawbah (Tavba)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/11")  
 
@starta_router.message(F.text == "Yunus (Yunus)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/12")  
 
@starta_router.message(F.text == "Hud (Hud)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/13")  
 
@starta_router.message(F.text == "Yusuf (Yusuf)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/14")  
 
@starta_router.message(F.text == "Ar-Ra'd (Momaqaldiroq)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/15")  
 
@starta_router.message(F.text == "Ibrahim (Ibrohim)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/16")  
 
@starta_router.message(F.text == "Al-Hijr (Hijr)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/17")   

@starta_router.message(F.text == "An-Nahl (Asalarilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/18")  

@starta_router.message(F.text == "Al-Isra (Isro)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/19")

@starta_router.message(F.text == "Al-Kahf (G'or)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/20") 

@starta_router.message(F.text == "Maryam (Maryam)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/21")

@starta_router.message(F.text == "Ta-Ha (Ta-Ha)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/22")  

@starta_router.message(F.text == "Al-Anbiya (Payg'ambarlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/23")  

@starta_router.message(F.text == "Al-Hajj (Haj)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/24")  
 
@starta_router.message(F.text == "Al-Mu'minun (Mo'minlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/25")  
 
@starta_router.message(F.text == "An-Nur (Nur)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/26")  
 
@starta_router.message(F.text == "Al-Furqan (Furqon)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/27")  
 
@starta_router.message(F.text == "Ash-Shu'ara (Shoirlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/28")  
 
@starta_router.message(F.text == "An-Naml (Naml)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/29")  
 
@starta_router.message(F.text == "Al-Qasas (Qissalar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/30")  
 
@starta_router.message(F.text == "Al-Ankabut (O'rgimchak)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/31")  
 
@starta_router.message(F.text == "Ar-Rum (Rumliklar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/32")  

@starta_router.message(F.text == "Luqman (Luqmon)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/33")  
 
@starta_router.message(F.text == "As-Sajda (Sajda)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/34") 
  
@starta_router.message(F.text == "Al-Ahzab (Ittifoqlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/35") 
 
@starta_router.message(F.text == "Saba' (Sabo)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/36") 
 
@starta_router.message(F.text == "Fatir (Yaratuvchilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/37") 
  
@starta_router.message(F.text == "Ya-Sin (Ya Sin)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/38")

@starta_router.message(F.text == "As-Saffat (Saf tortganlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/39") 
  
@starta_router.message(F.text == "Sad (Sad)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/40") 
  
@starta_router.message(F.text == "Az-Zumar (Guruhlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/41")  
 
@starta_router.message(F.text == "Ghafir (Gunohlarini kechiruvchi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/42")  
 
@starta_router.message(F.text == "Fussilat (Tafsilotlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/43")  
 
@starta_router.message(F.text == "Ash-Shura (Maslahat)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/44")  
 
@starta_router.message(F.text == "Az-Zukhruf (Zeb-ziynat)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/45")  
 
@starta_router.message(F.text == "Ad-Dukhan (Tutun)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/46")   

@starta_router.message(F.text == "Al-Jathiya (Tizzalarni bukuvchilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/47")  
 
@starta_router.message(F.text == "Al-Ahqaf (Qum tepaliklari)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/48")  
 
@starta_router.message(F.text == "Muhammad (Muhammad)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/49")  
 
@starta_router.message(F.text == "Al-Fath (Fath)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/50")  
 
@starta_router.message(F.text == "Al-Hujurat (Xonalar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/51")  
 
@starta_router.message(F.text == "Qaf (Qof)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/52")  
 
@starta_router.message(F.text == "Az-Zariyat")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/53")  
 
@starta_router.message(F.text == "At-Tur (Tur tog'i)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/54")  
 
@starta_router.message(F.text == "An-Najm (Yulduz)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/55")  
 
@starta_router.message(F.text == "Al-Qamar (Oy")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/56") 
 
@starta_router.message(F.text == "Ar-Rahman (Mehribon)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/57")  

@starta_router.message(F.text == "Al-Waqi'a (Voqea)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/58")  
 
@starta_router.message(F.text == "Al-Hadid (Temir)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/59")  

@starta_router.message(F.text == "Al-Mujadila (Munozara qiluvchi ayol)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/60")  
 
@starta_router.message(F.text == "Al-Hashr (Ko'chirish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/61")  

@starta_router.message(F.text == "As-Saff (Saf)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/63")  
 
@starta_router.message(F.text == "Al-Jumu'ah (Juma)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/64") 

@starta_router.message(F.text == "Al-Munafiqun (Munofiqlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/65")  
 
@starta_router.message(F.text == "At-Taghabun (Zarar ko'rish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/66") 

@starta_router.message(F.text == "At-Talaq (Taloq)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/66") 
 
@starta_router.message(F.text == "At-Tahrim (Harom qilish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/68")  
 
@starta_router.message(F.text == "Al-Mulk (Mulk)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/69")        
 
@starta_router.message(F.text == "Al-Qalam (Qalam)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/70")        
 
@starta_router.message(F.text == "Al-Haqqah (Haqiqat)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/71")        
 
@starta_router.message(F.text == "Al-Ma'arij (Ma'rij)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/72")  

@starta_router.message(F.text == "Nuh (Nuh)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/73")        
 
@starta_router.message(F.text == "Al-Jinn (Jinlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/74")        
 
@starta_router.message(F.text == "Al-Muzzammil (O'ralgan kishi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/75")        
 
@starta_router.message(F.text == "Al-Muddathir (O'ranib olgan kishi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/76")        
        
@starta_router.message(F.text == "Al-Qiyama (Qiyomat)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/77")        
 
@starta_router.message(F.text == "Al-Insan (Inson)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/78")        
 
@starta_router.message(F.text == "Al-Mursalat (Elchilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/79")        
 
@starta_router.message(F.text == "An-Naba' (Xabar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/80") 

@starta_router.message(F.text == "An-Nazi'at (Qo'zg'olonchilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/81")        
 
@starta_router.message(F.text == "Abasa (Yuz burdi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/82")        
 
@starta_router.message(F.text == "At-Takwir (Bukilish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/83")        
 
@starta_router.message(F.text == "Al-Infitar (Yorilish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/84")        

@starta_router.message(F.text == "Al-Mutaffifin (Kamchilik qiluvchilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/85")        
@starta_router.message(F.text == "Al-Inshiqaq (Yorilish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/86")        

@starta_router.message(F.text == "Al-Buruj (Burjlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/87")        

@starta_router.message(F.text == "At-Tariq (Yulduz)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/88")        

@starta_router.message(F.text == "Al-A'la (Eng oliy)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/89")        

@starta_router.message(F.text == "Al-Ghashiya (Qoplovchi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/90")        

@starta_router.message(F.text == "Al-Fajr (Tong)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/91")        

@starta_router.message(F.text == "Al-Balad (Shahar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/92")        

@starta_router.message(F.text == "Ash-Shams (Quyosh)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/93")        

@starta_router.message(F.text == "Al-Lail (Tun)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/94")        

@starta_router.message(F.text == "Ad-Duha (Tonggi yorug'lik)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/95")        

@starta_router.message(F.text == "Ash-Sharh (Kengaytirish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/96")        

@starta_router.message(F.text == "At-Tin (Anjir)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/97")        

@starta_router.message(F.text == "Al-Alaq (Xo'ploq)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/98")        

@starta_router.message(F.text == "Al-Qadr (Qadr kechasi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/99")        

@starta_router.message(F.text == "Al-Bayyina (Aniq dalil)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/100")        

@starta_router.message(F.text == "Az-Zalzala (Zilzila)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/101")        

@starta_router.message(F.text == "Al-Adiyat (Yuguruvchilar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/102")        

@starta_router.message(F.text == "Al-Qari'a (Qo'ng'iroq)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/103")        

@starta_router.message(F.text == "At-Takathur (Ko'paytirish)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/104")        

@starta_router.message(F.text == "Al-Asr (Asr)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/105")        

@starta_router.message(F.text == "Al-Humaza (G'iybatchi)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/106")        

@starta_router.message(F.text == "Al-Fil (Fil)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/107")        

@starta_router.message(F.text == "Quraish (Quraysh)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/108")        

@starta_router.message(F.text == "Al-Ma'un (Yordam")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/109")        

@starta_router.message(F.text == "Al-Kawthar (Kavsar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/110")        

@starta_router.message(F.text == "Al-Kafirun (Kofirlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/111")        

@starta_router.message(F.text == "An-Nasr (Yordam)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/112")        

@starta_router.message(F.text == "Al-Masad (Palm fiber)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/113")        

@starta_router.message(F.text == "Al-Ikhlas (Ihlos)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/114")        

@starta_router.message(F.text == "Al-Falaq (Tong)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/115")        

@starta_router.message(F.text == "An-Nas (Insonlar)")
async def uzb_kinolar(message:Message):
    await message.answer_audio(audio="https://t.me/alafasy_quron/116")        

@starta_router.message(F.text == "salom")
async def uzb_kinolar(message:Message):
    await message.answer(text="tepada ko'rsatilgan tugmalardan foydalang iltmos")        


    