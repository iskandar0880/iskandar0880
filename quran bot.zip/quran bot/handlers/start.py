from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart
from keyboards.ilen_tugmalar import inline_menu
from aiogram import F
start_router: Router = Router()

@start_router.message(CommandStart())
async def start(message:Message):
    await message.answer(text="Assalomu alaykum aziz dindoshim,hush kelibsiz!Biz sizga Qur'oni Karimning istalgan surasini topishingizda yordam beramiz. Buning uchun siz oʻzingizga kerakli boʻlgan ma'lumot turini tanlang!")
    await message.answer("Ma'lumot turini tanlang.",reply_markup=inline_menu )

