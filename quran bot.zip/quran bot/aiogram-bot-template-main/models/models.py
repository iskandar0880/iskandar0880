from pydantic import BaseModel

# Create your models here.
