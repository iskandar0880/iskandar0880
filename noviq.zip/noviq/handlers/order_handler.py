from aiogram import Router, types, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from dotenv import load_dotenv
from keyboards.keyboards import main_menu
import os

# .env faylini yuklash
load_dotenv()
ADMIN_GROUP_ID = int(os.getenv("ADMIN_GROUP_ID"))  # Guruh ID

# Router yaratish
order_handler_router: Router = Router()

# Buyurtma holatlari
class OrderStates(StatesGroup):
    waiting_for_name = State()  # Ismni kutish
    waiting_for_phone = State()  # Telefon raqamini kutish
    waiting_for_comment = State()  # Izohni kutish

# Tugmalarning to'g'ri variantlari
valid_options = [
    "📝 Vizitka sayt", "🏢 Korporativ sayt", "🛒 Internet-do‘kon", "🔧 Maxsus loyiha",
    "💬 Oddiy bot", "🛍 Savdo bot", "⚙ Xizmat bot", "🤖 AI yoki maxsus bot"
]

# Telefon raqamini olish uchun tugma
phone_menu = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="📞 Telefon raqamni yuborish", request_contact=True)]],
    resize_keyboard=True,
    one_time_keyboard=True
)

# Tugmalardan birini bosganda ishga tushadi
@order_handler_router.message(lambda message: message.text in valid_options)
async def start_order(message: types.Message, state: FSMContext):
    await state.update_data(order_type=message.text)  # Buyurtma turini saqlash
    await message.answer("Iltimos, ismingizni yuboring.")
    await state.set_state(OrderStates.waiting_for_name)

# Foydalanuvchidan ism olish
@order_handler_router.message(StateFilter(OrderStates.waiting_for_name))
async def ask_name(message: types.Message, state: FSMContext):
    await state.update_data(user_name=message.text)     
    await message.answer("📞 Telefon raqamingizni yuboring:", reply_markup=phone_menu)
    await state.set_state(OrderStates.waiting_for_phone)

# Telefon raqamini olish
@order_handler_router.message(StateFilter(OrderStates.waiting_for_phone))
async def ask_phone(message: types.Message, state: FSMContext):
    if not message.contact:
        await message.answer("❌ Iltimos, quyidagi tugma orqali telefon raqamingizni yuboring.", reply_markup=phone_menu)
        return

    await state.update_data(user_phone=message.contact.phone_number)
    await message.answer("💬 Buyurtmangizga izoh yozing:", reply_markup=ReplyKeyboardRemove())
    await state.set_state(OrderStates.waiting_for_comment)

# Izohni olish va guruhga yuborish
@order_handler_router.message(StateFilter(OrderStates.waiting_for_comment))
async def ask_comment(message: types.Message, state: FSMContext, bot: Bot):
    await state.update_data(user_comment=message.text)

    # Foydalanuvchi ma'lumotlarini olish
    user_data = await state.get_data()
    text = (
        "📝 Yangi buyurtma!\n\n"
        f"📌 Buyurtma turi: {user_data.get('order_type')}\n"
        f"👤 Foydalanuvchi: {user_data.get('user_name')}\n"
        f"📞 Telefon: {user_data.get('user_phone')}\n"
        f"💬 Izoh: {user_data.get('user_comment')}\n"
    )

    # Foydalanuvchining Telegram ID va username ni olish
    telegram_profile = f"@{message.from_user.username}" if message.from_user.username else f"ID: {message.from_user.id}"

    # Telegram profilini qo'shish
    text += f"📱 Telegram profil: {telegram_profile}\n"

    # Guruhga yuborish
    await bot.send_message(ADMIN_GROUP_ID, text)
    await message.answer("✅ Buyurtmangiz muvaffaqiyatli yuborildi!", reply_markup=main_menu)

    # Holatni tozalash
    await state.clear()
