from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart
import html  # Maxsus belgilarni qochirish uchun
from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from dotenv import load_dotenv
import os 
from keyboards.keyboards import main_menu


  

start_router: Router = Router()

@start_router.message(CommandStart())
async def command_start_handler(message: Message) -> None:
    # Foydalanuvchi ma'lumotlarini olish
    user_full_name = html.escape(message.from_user.full_name or "Hurmatli foydalanuvchi")
    
    # Iliq va chiroyli salomlashish
    welcome_text = (
  f"🌟 <b>Assalomu alaykum, {user_full_name}!</b>\n"
        "😊 Sizni <b>noviq</b> botida ko‘rib turganimizdan xursandmiz!\n\n"
        "<b>💻 noviq haqida:</b>\n"
        "Biz mijozlarimiz uchun zamonaviy <b>veb-saytlar</b> va <b>Telegram botlar</b> yaratamiz.\n\n"
        "✅ <i>Biznesingiz uchun professional veb-sayt kerakmi?</i>\n"
        "✅ <i>Avtomatlashtirilgan Telegram bot yasashni xohlaysizmi?</i>\n\n"
        "📊 <b>Narxlar</b> bo‘limi orqali xizmatlarimiz haqidagi ma’lumotlarni ko‘rishingiz mumkin.\n\n"
        "📜 <b>Menyu haqida:</b>\n"
        "Ushbu bot orqali siz <b>veb-sayt</b> va <b>Telegram bot</b> buyurtma qilish, "
        "xizmatlarimiz narxlari bilan tanishish va biz bilan bog‘lanish imkoniyatiga egasiz.\n\n"
        "☎️ <b>Qo‘shimcha ma’lumot yoki buyurtma uchun biz bilan bog‘laning!</b>"
    )
    
    
    # Javob yuborish
    await message.answer(welcome_text, parse_mode="HTML", reply_markup=main_menu)

 
 
 
 
 
 
 




