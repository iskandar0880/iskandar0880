import asyncio
import logging
from aiogram import Dispatcher

from handlers import echo
from handlers.start import start_router
from handlers.prices import prices_router
from handlers.order import order_router
from handlers.main import portfolio_router
from handlers.main import contact_router
from handlers.socials import socials_router
from handlers.order_handler import order_handler_router
from loader import bot, db

logger = logging.getLogger(__name__)

async def main():
    logging.basicConfig(level=logging.INFO)
    logger.info("Starting bot")

    try:
        db.create_table_users()
    except Exception as err:
        print(err)

    dp = Dispatcher()

    # Routerlarni alohida qo‘shamiz
    
    dp.include_router(start_router)  
    dp.include_router(prices_router)
    dp.include_router(order_router)
    dp.include_router(portfolio_router) 
    dp.include_router(contact_router) 
    dp.include_router(socials_router)
    dp.include_router(order_handler_router)
    dp.include_router(echo.router)

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped")
