# Aiogram 3 telegram bot

## O'rnatish
### Yuklab oling

1. ``git clone https://github.com/mehmonov/aiogram-bot-template.git``  yoki ``use template``

2. ``python -m venv env`` 

3. ``pip install -r requirements.txt``
