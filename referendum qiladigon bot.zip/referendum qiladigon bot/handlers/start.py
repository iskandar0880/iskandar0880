from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart
from aiogram import F
start_router: Router = Router()

@start_router.message(CommandStart())
async def generate_referat(message:Message):
    await message.answer(text="Assalomu alaykum aziz talaba bizning bu bot dan foydalanish blian sizning qinagan referatlar va mustaqil ishlarni bajarishingiz mumkun !")


