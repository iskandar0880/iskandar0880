import openai
from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

start_router: Router = Router()

# OpenAI API kalitini sozlash
openai.api_key = "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"  # Haqiqiy API kalitni kiriting


@start_router.message(CommandStart())
async def chat(message: Message):
    try:
        # OpenAI API orqali javob olish
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
               {"role": "user", "content": "Salom, yordam bera olasizmi?"}
    ]
        )
        # Javobni foydalanuvchiga yuborish
        reply = response['choices'][0]['message']['content']
        await message.answer(reply)
    except Exception as e:
        # Xatolarni qayta ishlash
        await message.answer(f"Xato yuz berdi: {str(e)}")
