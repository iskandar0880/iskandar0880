from aiogram import Router, F
from aiogram.types import Message, chat_member_updated
from aiogram.types.chat_member import ChatMember
from .chatbot import chat
router:Router = Router()






@router.message()
async def chatbot_handler(message: Message):
    suh = await chat(message.text)

    await message.reply(suh)

