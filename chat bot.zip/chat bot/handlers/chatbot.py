from openai import OpenAI


client = OpenAI(
    api_key="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"
)
async def chat (text):
  suh = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
      {"role": "system", "content": "sen bot san"},
      {"role": "user", "content": "text"}
    ]
    
  )
  return suh.choices[0].message.content
  print(suh.choices[0].message)
