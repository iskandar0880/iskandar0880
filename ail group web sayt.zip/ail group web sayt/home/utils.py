import requests

def send_telegram_message(order):
    bot_token = '7878871483:AAE9H1d1-6njNEP6KvC6eN0QgzBXIlanL_I'
    chat_id = '-1002439883306'  # To'g'ri ID ekanligiga ishonch hosil 
    text = (
        f"Yangi buyurtma:\n"
        f"Ism: {order.name}\n"
        f"Email: {order.email}\n"
        f"Telefon: {order.phone}\n"
        f"Telegram Profil: {order.telegram_profile}\n"
        f"Xabar: {order.message}"
    )

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': text,
    }
    response = requests.post(url, data=payload)

    print(response.status_code)
    print(response.json())

    if response.status_code != 200:
        print("Xatolik yuz berdi:", response.text)
    else:
        print("Xabar muvaffaqiyatli yuborildi.")
