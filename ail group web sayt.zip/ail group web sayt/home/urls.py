from django.urls import path,include
from . import views


urlpatterns = [
    path('' , views.home , name='home'),
    path('order/', views.order_view, name='order'),  # Buyurtma formasi
    path('order/success/', views.order_success, name='order_success'), 
    path('bizning-hizmatlar/', views.bizning_hizmatlar, name='bizning_hizmatlar'),
]
# utils.py


