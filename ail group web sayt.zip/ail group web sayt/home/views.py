# views.py

from django.shortcuts import render, redirect
from .forms import OrderForm
from .utils import send_telegram_message

def home(request):
    return render(request, 'base.html')

def home(request):
    return render(request, 'index.html')

def order_view(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save()  # Buyurtmani saqlaymiz
            send_telegram_message(order)  # Telegramga yuboramiz
            return redirect('order_success')  # Buyurtma muvaffaqiyatli yuborilganda yo'naltiramiz
    else:
        form = OrderForm()
    
    # GET so'rovi uchun `order_form.html`ni qaytaramiz
    return render(request, 'order_form.html', {'form': form})

def order_success(request):
    return render(request, 'order_success.html') 

def bizning_hizmatlar(request):
    return render(request, 'bizning_hizmatlar.html')



