from django.db import models
from django.db import models

class Order(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    telegram_profile = models.CharField(max_length=100, blank=True)  # Telegram profil maydoni
    message = models.TextField()

    def __str__(self):
        return f"{self.name} - {self.email}"
