LEXICON_RU: dict[str, str] = {
    # Commands
    "/start": ...,
    "/help": ...
}
