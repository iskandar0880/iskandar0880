from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram import Router, F
from aiogram.types import Message
html_router: Router = Router()
but_router: Router = Router()
w_router: Router = Router()
e_router: Router = Router()
r_router: Router = Router()
t_router: Router = Router()
y_router: Router = Router()
u_router: Router = Router()

html = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="HTML darslari" ),
            KeyboardButton(text="CSS darslari"),
        ],
    ],
    resize_keyboard=True
    )

dars_1= ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="daes1-2" ),
            KeyboardButton(text="dars3-4"),
        ],       
          [
            KeyboardButton(text="dars5-6" ),
            KeyboardButton(text="dars7-8"),
        ],       
          [
            KeyboardButton(text="dars9-10" ),
            KeyboardButton(text="dars11-12"),
        ],       
          [
            KeyboardButton(text="dars13-14" ),
            KeyboardButton(text="dars15-16"),
        ],
    ],
    resize_keyboard=True
    )



but = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Front-end" ),
            KeyboardButton(text="Back-end"),
        ],
    ],
    resize_keyboard=True
    )
@html_router.message(F.text == "HTML darslari")
async def uzb_kinolar(message:Message):
    await message.answer("HTML darslari",reply_markup=dars_1)
    
@but_router.message(F.text == "Front-end")
async def uzb_kinolar(message:Message):
    await message.answer("Front-end",reply_markup=html)

@w_router.message(F.text == "daes1-2")
async def uzb_kinolar(message:Message):
    await message.answer_video(video="BAACAglAAxkBAAOsZijW-0120vmkkppUsxu8-hAt9MEAAscQAALa_wlijxMYkXHeSus0BA")
    