from aiogram import Router, F
from aiogram.types import Message, chat_member_updated
from aiogram.types.chat_member import ChatMember
from aiogram.filters import CommandStart
from keyboards.but import but
start_router: Router = Router()

@start_router.message(CommandStart())
async def start_handler(message: Message):
    user = message.from_user.full_name
    await message.answer(f"🖥 Kompyuter savodxonligi va IT sohasiga doir o'zbekcha, foydali va bepul darslarni ulashuvchi innovatsion botga xush kelibsiz.",reply_markup = but)
